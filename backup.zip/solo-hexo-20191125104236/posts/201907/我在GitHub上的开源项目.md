title: 我在 GitHub 上的开源项目
date: '2019-07-22 10:57:22'
updated: '2019-07-22 10:57:22'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [JDKTest](https://github.com/mnizht/JDKTest) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/mnizht/JDKTest/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/mnizht/JDKTest/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/mnizht/JDKTest/network/members "分叉数")</span>





---

### 2. [MyPythonDemo](https://github.com/mnizht/MyPythonDemo) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/mnizht/MyPythonDemo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/mnizht/MyPythonDemo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/mnizht/MyPythonDemo/network/members "分叉数")</span>

阿里云Python学习路线



---

### 3. [firstSpringBootDemo](https://github.com/mnizht/firstSpringBootDemo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/mnizht/firstSpringBootDemo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/mnizht/firstSpringBootDemo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/mnizht/firstSpringBootDemo/network/members "分叉数")</span>



