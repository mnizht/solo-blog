title: 新服务器部署solo
date: '2019-05-16 17:03:05'
updated: '2019-05-16 18:14:34'
tags: [centos7, mysql8, Solo]
permalink: /articles/2019/05/16/1557997385589.html
---
vps : centos7

database: mysql8



安装mysql8

rpm 安装 mysql8

1. 下载rpm文件,在MySQL官网找到想要安装的版本下载地址  <https://dev.mysql.com/downloads/repo/yum/>

``` shell
   wget https://repo.mysql.com/mysql80-community-release-el7-3.noarch.rpm
```

2. 安装下载好的包 

``` shell
   rpm -ivh mysql80-community-release-el7-3.noarch.rpm
```
  执行结果：会在/etc/yum.repos.d/目录下生成两个repo文件mysql-community.repo mysql-community-source.repo
    
  更新yum 命令

``` shell
   yum clean all
   yum makecache
```

3. 使用yum安装mysql

``` shell
   yum install mysql-community-server
```

   (默认安装mysql最新版，若要选择其他版本，参考官方文档<https://dev.mysql.com/doc/mysql-yum-repo-quick-guide/en/>，需要先修改yum仓库中可用版本)

4. 开启MySQL服务
``` shell
   systemctl start mysqld
```
5. 获取初始密码登陆MySQL
``` shell
   cat /var/log/mysqld.log | grep password
```
   (若找不到此文件，可以使用 find / -name mysqld.log 查询出文件后查看)

6. 修改初始密码
``` mysql
   alter user 'root'@'localhost' identified by 'Local@user123';
```
   (密码规则要求包含大小写字母，数字和特殊字符，修改密码策略参考文档 <https://dev.mysql.com/doc/refman/8.0/en/validate-password-options-variables.html>)

7. 创建solo数据库
``` mysql
   create database solo default charset utf8 collate utf8_general_ci;
```

8. 创建可远程连接的用户并授权

``` mysql
   create user 'solo'@'%' identified by 'Local@user123';
   grant select,insert,update,references,delete,create,drop,alter,index,create view,show view on solo.* to 'solo'@'%';
```

9. 防火墙开通3306端口,否则远程连接会被拒绝

``` shell
	firewall-cmd --zone=public --add-port=3306/tcp --permanent
	firewall-cmd --reload
```

10. 安装docker

``` shell
yum -y install docker
```

11. 使用推荐脚本部署solo
``` shell
#!/bin/bash

#
# Solo docker 更新重启脚本
#
# 1. 请注意修改参数
# 2. 可将该脚本加入 crontab，每日凌晨运行来实现自动更新
#

docker pull b3log/solo
docker stop solo
docker rm solo
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="123456" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=http --server_host=localhost
```

JDBC 用户名和密码设置为刚才创建的solo用户（因为我的MySQL和solo都在同一个vps上，这里也可以直接用root用户。但是为了能够用navicat查看数据库，所以创建了个远程用户）

--server_host= 本机部署可用 localhost。 如果使用云服务器，就设置为服务器地址，也可使用映射了地址的域名。

配置错误参考 <https://hacpai.com/article/1474087427032>

创建脚本文件后需要给文件设置可执行权限

``` shell
chmod 700 docker-restart.sh
```
关于 700 的解释：每个文件都有读、写、执行权限。分别是 r=4, w=2, x=1;
rwx = 4+2+1 = 7   可读，可写，可执行
--- = 0				无权限
700   三个数字对应 文件拥有者，群组，其它组 用户

防火墙开通8080端口,否则远程连接会被拒绝

```shell
firewall-cmd --zone=public --add-port=8080/tcp --permanent
firewall-cmd --reload
```


万事具备，浏览器输入服务器地址和端口号来访问第一篇日志吧。