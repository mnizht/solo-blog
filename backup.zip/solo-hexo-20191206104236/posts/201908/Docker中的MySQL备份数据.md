title: Docker中的MySQL备份数据
date: '2019-08-29 16:12:59'
updated: '2019-08-29 16:13:59'
tags: [docker, mysql8]
permalink: /articles/2019/08/29/1567066379578.html
---
### Docker中的MySQL备份数据

之前写过一篇备份[备份数据库到github](http://www.zhuht.xyz/articles/2019/06/12/1560304695807.html) 的博客。不过那个时候数据库是直接安装在服务器上的，这次使用了docker中的mysql，原来的备份方式就需要修改一下。

特此记录一下踩到的坑。

#### 原来的备份是一个shell脚本完成

- 第一步是将要备份的数据查出来保存到本地
- 第二步是将数据同步到git上



#### 使用docker中的MySQL后遇到的问题

##### 脚本中连接数据库后查询数据的语句因为多了一层docker，所以无法直接使用

想到解决办法是把备份数据到本地这一步的脚本文件拆出来放在docker容器里执行。这一步考虑到同步数据到git时需要数据在本机上，所以又重新部署了mysql容器，专门挂载了文件夹用来存放备份的数据和备份脚本，避免再重新部署mysql容器后数据丢失。备份脚本可以看之前的博客。

##### 本机同步数据

```shell
#!/bin/bash
echo `date`
echo "run docker_mysql_backup.sh"
# docker exec -it mysql8 bash /var/backups/docker_mysql_backup.sh
docker exec  mysql8 bash /var/backups/docker_mysql_backup.sh

# wait 10s
ti1=`date +%s`
ti2=`date +%s`
i=$(( $ti2 - $ti1 ))
while [[ "$i" -lt "5" ]]
do
	ti2=`date +%s`
	i=$(($ti2 - $ti1))

done
echo 5 second later

#脚本文件追加git操作  
echo "start publish..."  
#切换文件夹  
cd /usr/local/mysql8/mysqlBackup/
git status
git add -A
git commit -m "push backup data"
git pull
git push  

```

-  docker exec ... 这一句，如果设置了定时任务，要记得去除 -it ,因为定时任务中无法开启虚拟终端
- wait 10s 这一步骤，是因为没这一步时脚本执行到git提交数据时，总是会提示没有东西改变，但是我去查看备份文件夹时备份数据是有的，所以我猜测是容器内备份数据后通过挂载的方式同步到本机是有延迟的，所以这里加了5秒延迟，问题解决。

##### 设置定时任务

```shell
$ vim /etc/crontab
 0 12,23 * * *  	root	 /usr/local/timingTasks/backup_mysql.sh >>/usr/local/timingTasks/logs/log_$(date +\%Y-\%m-\%d).log 
# 直接编辑crontab文件添加定时任务
```

- 定时任务设置了小时后，如果vps时区与本地时区不同，为了看着方便，我修改了vps时区。然后还需要重启一下cron,否则定时任务还是会按照原来的时区运行

  - ```shell
    $ rm -f /etc/localtime
    $ ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
    ```

    
