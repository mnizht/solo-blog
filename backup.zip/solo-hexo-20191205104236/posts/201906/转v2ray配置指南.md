title: (转)v2ray配置指南
date: '2019-06-25 16:55:09'
updated: '2019-06-25 17:07:33'
tags: [v2ray]
permalink: /articles/2019/06/25/1561452909260.html
---
# 1. V2Ray 配置指南

## 1.1. 声明

V2Ray 配置指南（下称本指南）是网友自发编写的关于 V2Ray 如何配置及使用的指南，与 V2Ray 官方并无任何关系。尽管 V2Ray 厚爱将本指南的链接放到了其官网首页，这并不意味着本指南的建议或推荐为 V2Ray 官方所主张。

## 1.2. 简介

### 1.2.1. 什么是 V2Ray？

V2Ray 是 Project V 下的一个工具。Project V 是一个包含一系列构建特定网络环境工具的项目，而 V2Ray 属于最核心的一个。 官方中介绍`Project V 提供了单一的内核和多种界面操作方式。内核（V2Ray）用于实际的网络交互、路由等针对网络数据的处理，而外围的用户界面程序提供了方便直接的操作流程。`不过从时间上来说，先有 V2Ray 才有 Project V。 如果还是不理解，那么简单地说，V2Ray 是一个与 Shadowsocks 类似的代理软件，可以用来科学上网（翻墙）学习国外先进科学技术。

V2Ray 用户手册：[https://www.v2ray.com](https://www.v2ray.com/)（已被墙） [https://v2ray.cool](https://v2ray.cool/)（已被墙） [https://mux.cool](https://mux.cool/)（还没被墙）

V2Ray 项目地址：<https://github.com/v2ray/v2ray-core>

V2Ray Telegram 使用群链接：<https://t.me/projectv2ray>

### 1.2.2. V2Ray 跟 Shadowsocks 有什么区别？

区别还是有的，Shadowsocks 只是一个简单的代理工具，而 V2Ray 定位为一个平台，任何开发者都可以利用 V2Ray 提供的模块开发出新的代理软件。

了解 Shadowsocks 历史的同学都知道，Shadowsocks 是 clowwindy 开发的自用的软件，开发的初衷只是为了让自己能够简单高效地科学上网，自己使用了很长一段时间后觉得不错才共享出来的。V2Ray 是 clowwindy 被喝茶之后 V2Ray 项目组为表示抗议开发的，一开始就致力于让大家更好更快的科学上网。

由于出生时的历史背景不同，导致了它们性格特点的差异。

简单来说，Shadowsocks 功能单一，V2Ray 功能强大。听起来似乎有点贬低 Shadowsocks 呢？当然不！换一个角度来看，Shadowsocks 简单好上手，V2Ray 复杂配置多。

### 1.2.3. 既然 V2Ray 复杂，为什么要用它？

童鞋，某事物的优点和缺点总是相生相随的。相对来说，V2Ray 有以下优势：

- **更完善的协议:** V2Ray 使用了新的自行研发的 VMess 协议，改正了 Shadowsocks 一些已有的缺点，更难被墙检测到

- **更强大的性能:** 网络性能更好，具体数据可以看 [V2Ray 官方博客](https://steemit.com/cn/@v2ray/3cjiux)

- 更丰富的功能:

   

  以下是部分 V2Ray 的功能

  - mKCP: KCP 协议在 V2Ray 上的实现，不必另行安装 kcptun
  - 动态端口：动态改变通信的端口，对抗对长时间大流量端口的限速封锁
  - 路由功能：可以随意设定指定数据包的流向，去广告、反跟踪都可以
  - 传出代理：看名字可能不太好理解，其实差不多可以称之为多重代理。类似于 Tor 的代理
  - 数据包伪装：类似于 Shadowsocks-rss 的混淆，另外对于 mKCP 的数据包也可伪装，伪装常见流量，令识别更困难
  - WebSocket 协议：可以 PaaS 平台搭建V2Ray，通过 WebSocket 代理。也可以通过它使用 CDN 中转，抗封锁效果更好
  - Mux:多路复用，进一步提高科学上网的并发性能

### 1.2.4. 哪有十全十美的东西？

少年悟性很高啊！当然没有！目前来说，V2Ray 有下面的缺点：

- 配置复杂
- 产业链不成熟

### 1.2.5. 为什么要写这篇文章？

虽然其文档很详细，换个说法就是很长，一般用户看到这么长的使用文档都有点望而却步。另外我用 Google 搜索过 V2Ray，搜出来的文章非常少，只能寥寥数篇，而且至少都是好几月之前的，由于 V2Ray 的迭代速度快，一些文章对目前的 V2Ray 已经不适用了。所以我希望通过本指南：

- 让大家了解到最新的 V2Ray 是什么样子的
- 让大家知道利用 V2Ray 可以做些什么
- 尝试用浅显易懂的语言来讲解 V2Ray 的配置
- 分享一些配置案例

然而最重要的是希望大家能够通过我写的配置指南看懂 V2Ray 的手册。

### 1.2.6. 听你说了这么多，好像 V2Ray 还不错的样子。但我只是要翻翻墙而已，不想花太多时间怎么办？

无论做什么都是有代价的，付出不一定有收获，但是不付出肯定没有收获。

### 1.2.7. 我决定尝试一下 V2Ray，那么我该如何使用这个指南？

V2Ray 的用户手册非常详细地解释了 V2Ray，本指南主要以实际可用的配置从易到难来讲解 V2Ray 的功能特性，力求降低新手使用 V2Ray 的难度。

**本指南的目标用户是有一定的 Linux 操作基础，像怎么注册 VPS，怎么用 SSH 登录 VPS，怎么使用 nano（或 vim） 编辑一个文本以及一些 Linux 基本命令的使用件网上有一大堆的指南，没必要重复造轮子再写一篇教程，如果这些你不会，强烈建议你去学会了再来尝试搭建 V2Ray。**

本指南可以看作 V2Ray 用户手册的简易版本，也可以看作 V2Ray 的应用举例。你可以在不参考 V2Ray 用户手册的情况下按照本指南的指导去搭建配置 V2Ray ，但我并不建议你这么做。因为本指南只是引导大家如何理解和配置 V2Ray，相较于用户手册来说有一定的取舍，会忽略一部分东西。所以我希望大家也花时间去阅读 V2Ray 用户手册。

### 1.2.8. 刚开始使用 V2Ray，有什么需要注意的吗？

由于许多 V2Ray 用户都有使用过 Shadowsocks 的经验，基本上可以按照使用 Shadowsocks 那样使用。但是 V2Ray 还是和 Shadowsocks 不太一样，所以我大概说一下使用上的差异。请注意，差异不代表好坏或优劣，如果一个事物必须拥有其他同类所拥有的东西，那么它也就没有了存在的意义。

- 客户端：V2Ray 本身只是一个内核，V2Ray 上的图形客户端大多是调用 V2Ray 内核套一个图形界面的外壳，类似于 Linux 内核和 Linux 操作系统的关系；而 Shadowsocks 的客户端都是自己重新实现了一遍 Shadowsocks 协议。本文的内容短期内不涉及图形客户端的使用。
- 分流：也许大家第一反映是 PAC，实际上无论是 Shadowsocks (特指 Shadowsocks-libev) 还是 V2Ray 本身不支持 PAC，都是客户端加进来的；Shadowsocks 的分流使用 ACL，V2Ray 使用自己实现的路由功能，孰优孰劣只是仁者智者的问题。
- 分享链接/二维码：V2Ray 不像 Shadowsocks 那样有统一规定的 URL 格式，所以各个 V2Ray 图形客户端的分享链接/二维码不一定通用。
- 加密方式：V2Ray (特指 VMess 协议) 不像 Shadowsocks 那样看重对加密方式的选择，并且 VMess 的加密方式是由客户端指定的，服务器自适应。
- 时间：使用 V2Ray 要保证时间准确，因为这是为了安全设计的。
- 密码：V2Ray(VMesss) 只有 id（使用 UUID 的格式），作用类似于 Shadowsocks 的密码，但随机性远好于 Shadowsocks 的密码，只是不太方便记忆(安全和方便的矛盾)。
- UDP 转发：VMess 是基于 TCP 的协议，对于 UDP 包 V2Ray 会转成 TCP 再传输的，即 UDP over TCP。要 UDP 转发功能在客户端的 socks 协议中开启 UDP 即可。
- 路由器翻墙：实际上它们并没有什么区别，不要以为没有插件就不能在路由器上用，看事物请看本质。

# 1. 开篇

本篇为开篇，只介绍 V2Ray 的安装方法以及 V2Ray 所使用的配置文件格式。这只是部署 V2Ray 过程中的第一步，故名开篇。



# 1. 部署之前

本节将说明在部署 V2Ray 的过程中需要注意的一些细节，看似无关紧要，但有些许差错可能就会造成部署失败。所以请大家请仔细阅读，在部署的过程如果遇到问题了，也请检查一下是不是哪些地方做得不到位。

## 1.1. 时间是否准确

V2Ray 对于时间有比较严格的要求，要求服务器和客户端时间差绝对值不能超过 2 分钟，所以一定要保证时间足够准确。还好 V2Ray 并不要求时区一致。比如说自个儿电脑上的时间是北京时间（东 8 区）2017-07-31 12:08:31，但是 VPS 上的时区是东 9 区，所以 VPS 上的时间应该是2017-07-31 13:06:31 到 2017-07-31 13:10:31 之间才能正常使用 V2Ray。当然，也可以自行改成自己想要的时区。

## 1.2. Linux 版本的问题

由于 V2Ray 使用的编程语言的特点，V2Ray 可以不依赖其它软件（库）而运行，并且可以在许多操作系统上运行（Windows、Linux、BSD等），但是由于新手在学习使用过程中可能会遇到各种问题，却缺乏相应的解决问题的能力，因此在 VPS 上建议与本指南一样使用 Debian 8.x 操作系统，或者使用 Debian 9.x 以上以及 Ubuntu 16.04 以上的系统。请不要迷信某个（些）“最稳定”的系统或系统版本。

## 1.3. 防火墙

有些朋友非要使用最稳定的 Linux，或者 VPS 是从比较为客户考虑的商家里买的，因此正确部署了 V2Ray 之后可能还是连不上。这时候你就要检查一下是否可能是防火墙的问题了。具体情况你可以发工单问客服或 Google。

## 1.4. 启动问题

使用脚本新安装 V2Ray 后不会自动运行，而是要自己手动运行。另外如果修改了配置文件，要重新启动 V2Ray 新的配置才会生效。

## 1.5. 配置文件的格式问题

因为 V2Ray 的配置文件比较长，层级也多，导致编辑时很容易出错，也难检查。如果使用在线的 JSON 工具（当然也有离线 的），可以检查文件格式是否正确。这种在线工具一搜一大把，就不打广告了。

## 1.6. 代理设置问题

在指南中使用的 FireFox 浏览器，设置的是 socks 代理。但是有的朋友喜欢用其它浏览器，那么我提示一下，客户端的 inbound 可以使用 HTTP 协议，并在 IE 选项中设置代理。或者也可以使用浏览器插件，如 SwitchyOmega 等。

## 1.7. 部署过程中的命令

本指南约定，所有以 $ 开头的都是命令行，不以 $ 开头的都不是命令。在实际输入命令时，都不需要将 $ 输进去。

**另外，本指南当中所有带 sudo 的命令都需要 su 权限。如果你不明白这句话的意思，可以直接使用 root 账户，则在输入命令时不需要输入 sudo 这几个字符。**

## 1.8. 阅读的问题

无论是在网络上，还是现实生活中，我发现不少人很喜欢跳跃式看文章/书/教程，自以为只看关键的东西就足够了，似乎这样子非常高效。实际上这样子做大多会花更多的时间才能达到同样的效果。所以如果你刚接触 V2Ray，又不太会使用，建议按照本指南的顺序并看完。

## 1.9. 绝技！最终解决问题

很遗憾，我没有能力预测所有可能出现的问题。但是，我可以告诉你，你遇到的所有问题都有人早就遇到了，并且还给出了相应的解决办法（除非你是该行业的顶尖人才，遇到的是需要调用浩瀚的资源才有希望解决的）。所以如果遇到问题，可以通过搜索引擎搜索解决，到社区里提问是迫不得已的办法。我可以很明确地说，在部署 V2Ray 的过程中，所遇到所有的问题有 90% 以上的问题可以通过搜索或者查看相关文档解决，要社区提问才能解决的不足 5%。如果不是，那么只能说明你的综合能力还需提高（比如查资料的能力、阅读理解能力的）。当然，我的意思并不是反对到社区提问，而是希望提问的东西能够有点意义，谁也不愿意自己就像个复读机一样天天回答网友们千篇一律的问题。如果有提问的需要，强烈建议先认真学习一个[提问的智慧](https://github.com/ryanhanwu/How-To-Ask-Questions-The-Smart-Way/blob/master/README-zh_CN.md)。



# 1. 安装

本节将说明如何安装 V2Ray，内容包含服务器安装和客户端安装。需要注意的是，与 Shadowsocks 不同，从软件上 V2Ray 不区分服务器版和客户端版，也就是说在服务器和客户端运行的 V2Ray 是同一个软件，区别只是配置文件的不同。因此 V2Ray 的安装在服务器和客户端上是一样的，但是通常情况下 VPS 使用的是 Linux 而 PC 使用的是 Windows，因此本章默认服务器为 Linux VPS，客户端为 Windows PC。如果你的 PC 使用的是 Linux 操作系统，那么请参考本文的服务器安装；VPS 使用的是 Windows，参考本文的客户端安装；如果你使用的是 MacOS ，请你自行研究怎么安装吧，安装完了跳过本节继续往下看。

本文中会有不少的命令以 sudo 开头，代表着以管理员权限运行，如果你是用 root 账户执行文中的命令，就不用打 sudo。

------

## 1.1. 时间校准

对于 V2Ray，它的验证方式包含时间，就算是配置没有任何问题，如果时间不正确，也无法连接 V2Ray 服务器的，服务器会认为你这是不合法的请求。所以系统时间一定要正确，只要保证时间误差在**90秒**之内就没问题。

对于 VPS(Linux) 可以执行命令 `date -R` 查看时间：

```
$ date -R
Sun, 22 Jan 2017 10:10:36 -0500
```

输出结果中的 -0500 代表的是时区为西 5 区，如果转换成东 8 区时间则为 `2017-01-22 23:10:36`。

如果时间不准确，可以使用 `date --set` 修改时间：

```
$ sudo date --set="2017-01-22 16:16:23"
Sun 22 Jan 16:16:23 GMT 2017
```

如果你的服务器架构是 OpenVZ，那么使用上面的命令有可能修改不了时间，直接发工单联系 VPS 提供商的客服吧，就说你在 VPS 上运行的服务对时间有要求，要他们提供可行的修改系统时间的方法。

对 VPS 的时间校准之后接着是个人电脑，如何修改电脑上的时间我想不必我多说了。

无论是 VPS 还是个人电脑，时区是什么无所谓，因为 V2Ray 会自动转换时区，但是时间一定要准确。

------

## 1.2. 服务器安装

### 1.2.1. 脚本安装

在 Linux 操作系统， V2Ray 的安装有脚本安装、手动安装、编译安装 3 种方式，选择其中一种即可，本指南仅提供使用使用脚本安装的方法，并仅推荐使用脚本安装，该脚本由 V2Ray 官方提供。该脚本仅可以在 Debian 系列或者支持 Systemd 的 Linux 操作系统使用。

**除非你是大佬，或者能够自行处理类似 command not found 的问题，否则请你使用 Debian 8.x 以上或者 Ubuntu 16.04 以上的 Linux 系统。** 本指南默认使用 Debian 8.7 系统作为示范。

首先下载脚本：

```
$ wget https://install.direct/go.sh
--2018-03-17 22:49:09--  https://install.direct/go.sh
Resolving install.direct (install.direct)... 104.27.174.71, 104.27.175.71, 2400:cb00:2048:1::681b:af47, ...
Connecting to install.direct (install.direct)|104.27.174.71|:443... connected.
HTTP request sent, awaiting response... 200 OK
Length: unspecified [text/plain]
Saving to: ‘go.sh’

go.sh                             [ <=>                                                 ]  11.24K  --.-KB/s    in 0.001s  

2018-03-17 22:49:09 (17.2 MB/s) - ‘go.sh’ saved [11510]
```

然后执行脚本安装 V2Ray:

```
$ sudo bash go.sh
Installing curl
Updating software repo
Installing curl
Selecting previously unselected package curl.
(Reading database ... 36028 files and directories currently installed.)
Preparing to unpack .../curl_7.38.0-4+deb8u5_amd64.deb ...
Unpacking curl (7.38.0-4+deb8u5) ...
Processing triggers for man-db (2.7.0.2-5) ...
Setting up curl (7.38.0-4+deb8u5) ...
Installing V2Ray v2.33 on x86_64
Donwloading V2Ray.
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100   608    0   608    0     0   2403      0 --:--:-- --:--:-- --:--:--  2412
100 2583k  100 2583k    0     0  1229k      0  0:00:02  0:00:02 --:--:-- 1847k
Installing unzip
Installing unzip
Selecting previously unselected package unzip.
(Reading database ... 36035 files and directories currently installed.)
Preparing to unpack .../unzip_6.0-16+deb8u3_amd64.deb ...
Unpacking unzip (6.0-16+deb8u3) ...
Processing triggers for mime-support (3.58) ...
Processing triggers for man-db (2.7.0.2-5) ...
Setting up unzip (6.0-16+deb8u3) ...
Extracting V2Ray package to /tmp/v2ray.
Archive:  /tmp/v2ray/v2ray.zip
  inflating: /tmp/v2ray/v2ray-v2.33-linux-64/readme.md  
  inflating: /tmp/v2ray/v2ray-v2.33-linux-64/systemd/v2ray.service  
  inflating: /tmp/v2ray/v2ray-v2.33-linux-64/systemv/v2ray  
  inflating: /tmp/v2ray/v2ray-v2.33-linux-64/v2ray  
  inflating: /tmp/v2ray/v2ray-v2.33-linux-64/vpoint_socks_vmess.json  
  inflating: /tmp/v2ray/v2ray-v2.33-linux-64/vpoint_vmess_freedom.json  
PORT:40827
UUID:505f001d-4aa8-4519-9c54-6b65749ee3fb
Created symlink from /etc/systemd/system/multi-user.target.wants/v2ray.service to /lib/systemd/system/v2ray.service.
V2Ray v2.33 is installed.
```

看到类似于这样的提示就算安装成功了。如果安装不成功脚本会有红色的提示语句，这个时候你应当按照提示除错，除错后再重新执行一遍脚本安装 V2Ray。对于错误提示如果看不懂，使用翻译软件翻译一下就好。

在上面的提示中，有一行 "PORT:40827" 代表着端口号为 40827，还有一行 "UUID:505f001d-4aa8-4519-9c54-6b65749ee3fb" 代表着 id 为 505f001d-4aa8-4519-9c54-6b65749ee3fb。这两个都是随机生成的，不用担心跟别人撞上了。

安装完之后，使用以下命令启动 V2Ray:

```
$ sudo systemctl start v2ray
```

在首次安装完成之后，V2Ray 不会自动启动，需要手动运行上述启动命令。而在已经运行 V2Ray 的 VPS 上再次执行安装脚本，安装脚本会自动停止 V2Ray 进程，升级 V2Ray 程序，然后自动运行 V2Ray。在升级过程中，配置文件不会被修改。

对于安装脚本，还有更多用法，在此不多说了，可以执行 `bash go.sh -h` 看帮助。

### 1.2.2. 升级更新

在 VPS，重新执行一遍安装脚本就可以更新了，在更新过程中会自动重启 V2Ray，配置文件保持不变。

```
$ sudo bash go.sh
```

V2Ray 的更新策略是快速迭代，每周更新(无意外的情况下)。版本号的格式是 `vX.Y.Z`，如 `v2.44.0`。v是固定的字母v，version 的首字母；X、Y、Z都是数字，X是大版本号，每年更新一个大版本(现在是 v4.Y.Z，V2Ray 已经走到了第四个年头)，Y 是小版本，每周五更新一个小版本。Z是区分正式版和测试版，Z是0代表着是正式版，不是0说明是测试版。例如，v4.7.0 是正式版，v4.7.1是测试版，建议只使用正式版，不手动指定的情况下V2Ray 的安装脚本也只会安装最新的正式版。

有些细心的朋友可能会注意到有时候周五 V2Ray 刚发布了一个新版本，次日或过两日又更新一个正式版。出现这种情况是因为周五发布的正式版出现了影响使用严重的 BUG，需要立马发布一个新版本。这种情况比较烦，但是为了保证兼容性、性能优化等又需要保证版本不要太老旧。所以我比较建议在周四更新，选这么一个日子是因为有重大的 BUG 肯定在前面几天就已经修复了，小问题(恐怕都不知道有)的话不会影响使用；而且版本号与最新版相比迟那么一两个也没什么关系。

## 1.3. 客户端安装

点[这里](https://github.com/v2ray/v2ray-core/releases)下载 V2Ray 的 Windows 压缩包，如果是 32 位系统，下载 v2ray-windows-32.zip，如果是 64 位系统，下载 v2ray-windows-64.zip（下载速度慢或无法下载请考虑挂已有的翻墙软件来下载）。下载并且解压之后会有下面这些文件：

- `v2ray.exe` 运行 V2Ray 的程序文件
- `wv2ray.exe` 同 v2ray.exe，区别在于wv2ray.exe是后台运行的，不像 v2ray.exe 会有类似于 cmd 控制台的窗口。运行 V2Ray 时从 v2ray.exe 和 wv2ray.exe 中任选一个即可
- `config.json` V2Ray 的配置文件，后面我们对 V2Ray 进行配置其实就是修改这个文件
- `v2ctl.exe` V2Ray 的工具，有多种功能，除特殊用途外，一般由 v2ray.exe 来调用，用户不用太关心
- `geosite.dat` 用于路由的域名文件
- `geoip.dat` 用于路由的 IP 文件
- `其它` 除上面的提到文件外，其他的不是运行 V2Ray 的必要文件。更详细的说明可以看 doc 文件夹下的 readme.md 文件，可以通过记事本或其它的文本编辑器打开查看

实际上双击 v2ray.exe （或wv2ray.exe） 就可以运行 V2Ray 了，V2Ray 会读取 config.json 中的配置与服务器连接。~~默认的配置文件包含 V2Ray 官方服务器的配置，也就是说你可以不自己搭建服务器而直接使用 V2Ray 提供的服务器科学上网。在不修改 config.json 的情况下，双击运行 v2ray.exe，可以直接科学上网~~（V2Ray 官方服务器已下线）。 ![img](https://toutyrater.github.io/resource/images/v2rayrunnig.png)

V2Ray 将所有选择权交给用户，它不会自动设置系统代理，因此还需要在浏览器里设置代理。以火狐（Firefox）为例，点菜单 -> 选项 -> 高级 -> 设置 -> 手动代理设置，在 SOCKS Host 填上 127.0.0.1，后面的 Port 填 1080，再勾上使用 SOCKS v5 时代理 DNS (这个勾选项在旧的版本里叫做远程 DNS)。操作图见下：

![img](https://toutyrater.github.io/resource/images/firefox_proxy_setting1.png)

![img](https://toutyrater.github.io/resource/images/firefox_proxy_setting2.png)

![img](https://toutyrater.github.io/resource/images/firefox_proxy_setting3.png)

![img](https://toutyrater.github.io/resource/images/firefox_proxy_setting4.png)

如果使用的是其它的浏览器，请自行在网上搜一下怎么设置 SOCKS 代理。

------

## 1.4. 更新历史

- 2017-08-06 加点提醒
- 2017-08-05 使用最新的脚本，脚本依然来自于 [V2Ray](https://raw.githubusercontent.com/v2ray/v2ray-core/master/release/install-release.sh)
- 2017-10-07 V2Ray 官方服务器已经恢复
- 2017-12-22 移除官方服务器
- 2017-12-29 加入 IPFS
- 2018-04-05 Update
- 2018-11-11 Update
- 2019-01-19 Update





# 1. V2Ray 配置格式

V2Ray 的配置文件为 JSON 格式，Shadowsocks 的配置也是 JSON 格式，但是 V2Ray 由于支持许多功能不可避免导致配置相对复杂一些。因此在实际配置前建议还是了解一下 JSON 的格式。 关于 JSON 的格式，可以看 [V2Ray文档](https://www.v2ray.com/chapter_02/)，里面的介绍简单明了，只是配置一下 V2Ray 只看这里足够了（我在 Google 上搜索关于 JSON 的文章比较啰嗦，估计是给程序员看的，咱没必要弄的晕头转向的。另外针对文档的介绍我认为还要补充几点：

- JSON 所有标点符号都要用半角符号（英文符号）

- 所有字符串都要加双引号 `" "`，键是字符串，所以键也要加双引号，数字不用加双引号

- 布尔类型也不用加双引号，布尔值只有两个就是 true 和 false，意思就是真（是）和假（否）

- 对象没有顺序，即大括号 `{ }` 括起来的内容顺序是怎么样都没关系，如

  ```javascript
  {
    "ip":"8.8.8.8",
    "port":53,
    "isDNS":true
  }
  ```

  ```javascript
  {
    "ip":"8.8.8.8",
    "isDNS":true,
    "port":53
  }
  ```

  上面两个 JSON 实际上是等效的

## 1.1. 更新历史

- 2018-04-05 Update
- 2018-07-08 Update



# 1. 基本篇

本篇是一些基本简单的配置。

在本篇当中会有大量描述语言对配置进行讲解，目的是为了让大家简要理解 V2Ray 的工作方式。

本章每小节的提供配置样例都有服务器和客户端的，也就是说你可以直接复制到你的机器上然后修改一下服务器地址即可使用，这是最少工作量的，你也可以针对自己的情况对其它的选项参数作调整。



# 1. VMess

VMess 协议是由 V2Ray 原创并使用于 V2Ray 的加密传输协议，如同 Shadowsocks 一样为了对抗墙的[深度包检测](https://zh.wikipedia.org/wiki/深度包检测)而研发的。在 V2Ray 上客户端与服务器的通信主要是通过 VMess 协议通信。

本小节给出了 VMess 的配置文件，其实也就是服务器和客户端的基本配置文件，这是 V2Ray 能够运行的最简单的配置。

V2Ray 使用 inbound(传入) 和 outbound(传出) 的结构，这样的结构非常清晰地体现了数据包的流动方向，同时也使得 V2Ray 功能强大复杂的同时而不混乱，清晰明了。形象地说，我们可以把 V2Ray 当作一个盒子，这个盒子有入口和出口(即 inbound 和 outbound)，我们将数据包通过某个入口放进这个盒子里，然后这个盒子以某种机制（这个机制其实就是路由，后面会讲到）决定这个数据包从哪个出口吐出来。以这样的角度理解的话，V2Ray 做客户端，则 inbound 接收来自浏览器数据，由 outbound 发出去(通常是发到 V2Ray 服务器)；V2Ray 做服务器，则 inbound 接收来自 V2Ray 客户端的数据，由 outbound 发出去(通常是如 Google 等想要访问的目标网站)。

------

## 1.1. 配置前的准备

实际上，根本不用准备什么，只要有一个文本编辑器(text editor)就可以修改配置了。但我还是打算啰嗦一些，因为我发现新手容易犯语法（格式）不正确的错误，这个很正常新手上路对路况总会不是很熟悉；另外一个就是不会使用工具，用了很多年电脑文本编辑还是 Windows 自带的记事本（在我身边有不少敲代码的，平常看某个代码文件很少打开 IDE 或者使用好点的文本编辑器，而是直接用记事本看），用水果刀切菜可以吗？当然可以，建议你亲自体验一下。如果你会用工具，会非常高效的而且装有一些插件可以语法检查，将代码格式化。

文本编辑器有许多，比如说 Sublime Text、VS code、atom、notepad++，上面这些都是跨平台的，具体如何使用请自行 Google 吧。这些软件都可以做到高亮显示、折叠、格式化等，建议使用，如果你不想安装软件，网上也有一些在线的 json 编辑器，还自动检查语法。如果你非要用 Windows 的记事本我也无话可说。

下面是一张 Windows 自带的记事本对比 Sublime Text 查看同一个 json 文件的图片，孰优孰劣大家心中自有判断。 ![img](https://toutyrater.github.io/resource/images/notepad_vs_ST.png)

又比如格式化功能： ![img](https://toutyrater.github.io/resource/images/formatdemo.gif)

对于 Linux 有一个软件叫 jq，可以执行这样的指令检查配置文件的语法是否正确：

```
$ jq . config.json
```

这里的 config.json 是当前目录下的 config.json。特别注意命令中的点 . 不能省去。

![img](https://toutyrater.github.io/resource/images/jqdemo.png)当我把 "23ad6b10-8d1a-40f7-8ad0-e3e35cd38297" 后的逗号 , 删去时：

![img](https://toutyrater.github.io/resource/images/jqerror.png)

（从 v2.11 起新增了一个注释功能，配置文件允许 `//` 和 `/**/` 注释。但是 JSON 的标准格式的没有注释的，也就是说如果你给配置文件加了注释，再使用上文我说的格式化功能会报错说你的 JSON 语法（格式）不对。）

不过，最好还是使用 V2Ray 提供的配置检查功能（test 选项），因为可以检查 JSON 语法错误外的问题，比如说突然间手抖把 vmess 写成了 vmss，一下子就检查出来了。

```
$ /usr/bin/v2ray/v2ray -test -config /etc/v2ray/config.json
failed to parse json config: Ext|Tools|Conf|Serial: failed to parse json config > Ext|Tools|Conf: failed to load inbound detour config. > Ext|Tools|Conf: unknown config id: vmss
Main: failed to read config file: /etc/v2ray/config.json > Main|Json: failed to execute v2ctl to convert config file. > exit status 255
```

如果是配置文件没问题，则是这样的：

```
$ /usr/bin/v2ray/v2ray -test -config /etc/v2ray/config.json
V2Ray v3.15 (die Commanderin) 20180329
An unified platform for anti-censorship.
Configuration OK.
```

## 1.2. 配置

以下给出了 VMess 的配置文件，包含客户端和服务器端，将你的配置替换成下面给出的配置，然后将服务器地址修改成你的就可以正常使用。修改完配置之后要重启 V2Ray 才能使用新配置生效。

**VMess 协议的认证基于时间，一定要保证服务器和客户端的系统时间相差要在90秒以内。**

### 1.2.1. 客户端配置

以下是客户端配置，将客户端的 config.json 文件修改成下面的内容，修改完成后要重启 V2Ray 才会使修改的配置生效。

```javascript
{
  "inbounds": [
    {
      "port": 1080, // 监听端口
      "protocol": "socks", // 入口协议为 SOCKS 5
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      },
      "settings": {
        "auth": "noauth"  //socks的认证设置，noauth 代表不认证，由于 socks 通常在客户端使用，所以这里不认证
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vmess", // 出口协议
      "settings": {
        "vnext": [
          {
            "address": "serveraddr.com", // 服务器地址，请修改为你自己的服务器 IP 或域名
            "port": 16823,  // 服务器端口
            "users": [
              {
                "id": "b831381d-6324-4d53-ad4f-8cda48b30811",  // 用户 ID，必须与服务器端配置相同
                "alterId": 64 // 此处的值也应当与服务器相同
              }
            ]
          }
        ]
      }
    }
  ]
}
```

在配置当中，有一个 id (在这里的例子是 b831381d-6324-4d53-ad4f-8cda48b30811)，作用类似于 Shadowsocks 的密码(password), VMess 的 id 的格式必须与 UUID 格式相同。关于 id 或者 UUID 没必要了解很多，在这里只要清楚以下几点就足够了：

- 相对应的 VMess 传入传出的 id 必须相同（如果你不是很明白这句话，那么可以简单理解成服务器与客户端的 id 必须相同）
- 由于 id 使用的是 UUID 的格式，我们可以使用任何 UUID 生成工具生成 UUID 作为这里的 id。比如 [UUID Generator](https://www.uuidgenerator.net/) 这个网站，只要一打开或者刷新这个网页就可以得到一个 UUID，如下图。或者可以在 Linux 使用命令 `cat /proc/sys/kernel/random/uuid` 生成。

![img](https://toutyrater.github.io/resource/images/generate_uuid.png)

### 1.2.2. 服务器配置

以下是服务器配置，将服务器 /etc/v2ray 目录下的 config.json 文件修改成下面的内容，修改完成后要重启 V2Ray 才会使修改的配置生效。

```javascript
{
  "inbounds": [
    {
      "port": 16823, // 服务器监听端口
      "protocol": "vmess",    // 主传入协议
      "settings": {
        "clients": [
          {
            "id": "b831381d-6324-4d53-ad4f-8cda48b30811",  // 用户 ID，客户端与服务器必须相同
            "alterId": 64
          }
        ]
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",  // 主传出协议
      "settings": {}
    }
  ]
}
```

## 1.3. 原理简析

根据上文给出的配置，在这里简单的介绍一下 V2Ray 的工作原理。

无论是客户端还是服务器，配置文件都由两部分内容组成： `inbounds` 和 `outbounds`。V2Ray 没有使用常规代理软件的 C/S（即客户端/服务器）结构，它既可以当做服务器也可以作为客户端。于是我们可以从另一个角度来理解，认为每一个 V2Ray 都是一个节点，`inbound` 是关于如何与上一个节点连接的配置，`outbound` 是关于如何与下一个节点连接的配置。对于第一个节点，`inbound` 与浏览器连接；对于最后一个节点，`outbound`与目标网站连接。`inbounds` 和 `outbounds` 是 `inbound` 和 `outbound` 的集合，意味着每一个 V2Ray 节点都可以有多个入口和出口。本例当中的入口和出口都只有一个，这是为了便于说明和理解。

### 1.3.1. 客户端

客户端配置中的 inbounds，port 为 1080，即 V2Ray 监听了一个端口 1080，协议是 socks。之前我们已经把浏览器的代理设置好了（SOCKS Host: 127.0.0.1，Port: 1080），假如访问了 google.com，浏览器就会发出一个数据包打包成 socks 协议发送到本机（127.0.0.1指的本机，localhost）的 1080 端口，这个时候数据包就会被 V2Ray 接收到。

再看 outbounds，protocol 是 vmess，说明 V2Ray 接收到数据包之后要将数据包打包成 [VMess](https://www.v2ray.com/chapter_03/01_effective.html#vmess-协议) 协议并且使用预设的 id 加密（这个例子 id 是 b831381d-6324-4d53-ad4f-8cda48b30811），然后发往服务器地址为 serveraddr.com 的 16823 端口。服务器地址 address 可以是域名也可以是 IP，只要正确就可以了。

在客户端配置的 inbounds 中，有一个 `"sniffing"` 字段，V2Ray 手册解释为“流量探测，根据指定的流量类型，重置所请求的目标”，这话不太好理解，简单说这东西就是从网络流量中识别出域名。这个 sniffing 有两个用处：

1. 解决 DNS 污染；
2. 对于 IP 流量可以应用后文提到的域名路由规则；
3. 识别 BT 协议，根据自己的需要拦截或者直连 BT 流量(后文有一节专门提及)。

如果这段话不懂，没关系，照着写吧。但是，如果你使用 Tor 浏览器，就不要开启 sniffing (将 sniffing 下的 enabled 设成 false)，否则会导致 Tor 无法上网。

### 1.3.2. 服务器

接着看服务器，服务器配置的 id 是 b831381d-6324-4d53-ad4f-8cda48b30811，所以 V2Ray 服务器接收到客户端发来的数据包时就会尝试用 b831381d-6324-4d53-ad4f-8cda48b30811 解密，如果解密成功再看一下时间对不对，对的话就把数据包发到 outbound 去，outbound.protocol 是 freedom（freedom 的中文意思是自由，在这里姑且将它理解成直连吧），数据包就直接发到 google.com 了。

实际上数据包的流向就是：

```
{浏览器} <--(socks)--> {V2Ray 客户端 inbound <-> V2Ray 客户端 outbound} <--(VMess)-->  {V2Ray 服务器 inbound <-> V2Ray 服务器 outbound} <--(Freedom)--> {目标网站}
```

配置中还有一个 alterId 参数，这个参数主要是为了加强防探测能力。理论上 alterId 越大越好，但越大就约占内存(只针对服务器，客户端不占内存)，所以折中之下设一个中间值才是最好的。那么设多大才是最好的？其实这个是分场景的，我没有严格测试过这个，不过根据经验，alterId 的值设为 30 到 100 之间应该是比较合适的。alterId 的大小要保证客户端的小于等于服务器的。

有人疑惑请求发出去后数据怎么回来，毕竟大多数的场景是下载。这个其实不算是问题，既然请求通过 V2Ray 发出去了，响应数据也会通过 V2Ray 原路返回（也许会有朋友看到这话会马上反驳说不一定是原路返回的，有这种想法的估计是非常了解 TCP/IP 协议的，何必较这个劲，这是底层的东西，又掌控在运营商手里，从应用层理解原路返回又有何不可）。

------

## 1.4. 注意事项

- 为了让浅显地介绍 V2Ray 的工作方式，本节中关于原理简析的描述有一些地方是错误的。但我知识水平又不够，还不知道该怎么改，暂且将错就错。正确的工作原理在用户手册的 [VMess 协议](https://www.v2ray.com/developer/protocols/vmess.html) 有详细的说明。
- id 为 UUID 格式，请使用软件生成，不要尝试自己造一个，否则很大程度上造出一个错误的格式来。
- VMess 协议可以设定加密方式，但 VMess 不同的加密方式对于过墙没有明显差别，本节没有给出相关配置方式（因为这不重要，默认情况下 VMess 会自己选择一种比较合适的加密方式），具体配置可见 [V2Ray 手册](https://v2ray.com/chapter_02/protocols/vmess.html)，不同加密方式的性能可参考[性能测试](https://toutyrater.github.io/app/benchmark.html)。

------

## 1.5. 排错指引

按照前文的指导操作，通常都能成功部署 V2Ray。然而总会有部分读者可能是看漏某些地方，导致虽然安装好了却无法连接。如果出现了这样的问题，可以尝试按下面的步骤一一进行排错。

### 1.5.1. 打开客户端闪退

可能原因：客户端的配置文件上不正确。

修正方法：请仔细检查配置文件并修改正确。

### 1.5.2. 客户端提示 Socks: unknown Socks version:

可能原因：客户端配置的 inboud 设置成了 socks 而浏览器的代理协议设置为 http。

修正方法：修改配置文件使客户端的 inboud 的 protocol 和浏览器代理设置的协议保持一致。

### 1.5.3. 客户端提示 Proxy|HTTP: failed to read http request > malformed HTTP request "\x05\x01\x00"

可能原因：客户端配置的 inboud 设置成了 https 而浏览器的代理协议设置为 socks4 或者 socks5。

修正方法：修改配置文件使客户端的 inboud 的 protocol 和浏览器代理设置的协议保持一致。

### 1.5.4. 服务器执行 systemctl status v2ray 输出提示 Main: failed to read config file...

可能原因：服务器的配置文件不正确。

修正方法：请仔细检查配置文件并修改正确。

### 1.5.5. 执行 cat /var/log/v2ray/error.log 或者 systemctl status v2ray 出现 rejected Proxy|VMess|Encoding: invalid user

可能原因：服务器与客户端的系统时间或者 id 不一致或者 alterId 不一致。

修正方法：请校准系统时间或将 id 以及 alterId 修改一致。

### 1.5.6. 以上几点都排除之后，请仔细检查：

1). 浏览器的代理设置中的端口号与客户端的 inbound 的 port 是否一致；

2). 客户端中的 outbound 设置的 address 与 vps 的ip是否一致；

3). 客户端中的 outbound 设置的address 与服务器的 inbound 的 port 是否一致；

4). VPS 是否开启了防火墙将连接拦截了；

5). 客户端是否安装在如学校、公司之类的场所，如果是，确认这些单位是否有防火墙拦截了连接；

对于 1) 到 3)，可以通过检查配置确定是否有问题。对于 4) 和 5)，你需要与 VPS 提供商和单位网管联系沟通。

### 1.5.7. 如果你仔细检查了以上几点并将问题排除了，结果还是无法通过 V2Ray 上网，那么你可以考虑：

1). 仔细看前方的教程，逐步按照教程来不要错在漏，重新部署 V2Ray。部署过程中时刻注意[部署之前](https://toutyrater.github.io/prep/start.html)提到的注意点；

2). 直接放弃；

3). 向大婶请教。

------

## 1.6. 更新历史

- 2017-08-08 排错指引补充
- 2017-08-06 添加排错指引
- 2018-02-09 补充说明
- 2018-04-05 内容补充
- 2018-09-03 更进一些 V2Ray 的变化，并修改一些描述
- 2018-11-09 跟进新 v4.0+ 的配置格式
- 2018-02-01 domainOverride 改为 sniffing



# 1. Shadowsocks

本节讲述 Shadowsocks 的配置。

什么？这不是 V2Ray 吗？怎么说配置 Shadowsocks 呢？

骚年别紧张。V2Ray 集成有 Shadowsocks 模块的，用 V2Ray 配置成 Shadowsocks 服务器或者 Shadowsocks 客户端都是可以的，兼容 Shadowsocks-libev。

配置与 VMess 大同小异，客户端服务器端都要有入口和出口，只不过是协议(protocol)和相关设置(settings)不同，不作过多说明，直接给配置，如果你配置过 Shadowsocks，对比之下就能够明白每个参数的意思(配置还有注释说明呢)。

## 1.1. 配置

### 1.1.1. 客户端配置

```javascript
{
  "inbounds": [
    {
      "port": 1080, // 监听端口
      "protocol": "socks", // 入口协议为 SOCKS 5
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      },
      "settings": {
        "auth": "noauth"  // 不认证
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "shadowsocks",
      "settings": {
        "servers": [
          {
            "address": "serveraddr.com", // Shadowsocks 的服务器地址
            "method": "aes-128-gcm", // Shadowsocks 的加密方式
            "ota": true, // 是否开启 OTA，true 为开启
            "password": "sspasswd", // Shadowsocks 的密码
            "port": 1024  
          }
        ]
      }
    }
  ]
}
```

### 1.1.2. 服务器配置

```javascript
{
  "inbounds": [
    {
      "port": 1024, // 监听端口
      "protocol": "shadowsocks",
      "settings": {
        "method": "aes-128-gcm",
        "ota": true, // 是否开启 OTA
        "password": "sspasswd"
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",  
      "settings": {}
    }
  ]
}
```

### 1.1.3. 注意事项

- 因为协议漏洞，Shadowsocks 已放弃 OTA(一次认证) 转而使用 AEAD，V2Ray 的 Shadowsocks 协议已经跟进 AEAD，但是仍然兼容 OTA。建议使用 AEAD (method 为 aes-256-gcm、aes-128-gcm、chacha20-poly1305 即可开启 AEAD), 使用 AEAD 时 OTA 会失效；
- ~~可以搭配 simple-obfs 使用，具体我没试过，有这个需要的就自己研究吧~~(Shadowsocks 已经弃用 simple-obfs)；
- 可以使用 V2Ray 的传输层配置（详见[高级篇](https://toutyrater.github.io/advanced/)），~~但如果这么设置了将与原版 Shadowsocks 不兼容~~（兼容 Shadowsocks 新增的 [v2ray-plugin](https://github.com/shadowsocks/v2ray-plugin)插件)。

### 1.1.4. 更新历史

- 2018-02-09 AEAD 更新
- 2018-09-03 描述更新
- 2018-11-09 跟进 v4.0+ 的配置格式
- 2019-01-19 v2ray-plugin



# 1. 日志文件

使用一个软件总是不可避免出现一些问题，比如说你用着某个软件突然间崩溃了，兴冲冲向开发者反馈说软件有崩溃现象。开发者问你日志，你没有；问你详细情况，你支支吾吾说不出来。比较和蔼的开发者可能会跟你说：好的，我知道了，这个问题会解决的。内心独白却是：mdzz，啥也说不出来，日志也没有还瞎 bb。

以上纯属杜撰，我非计算机软件的从业人员，不清楚里边的情况，诸位看官一看笑过便好不必当真。

但是，对于软件开发者来说使用查看日志是一种非常有效的调试手段。普通用户使用日志可以知道软件的运行状况，并且当软件出现异常时提供日志给开发者可以令开发者更加容易找到问题的根源，加快修复问题。

## 1.1. 配置

### 1.1.1. 客户端配置

```javascript
{
  "log": {
    "loglevel": "warning", // 日志级别
    "access": "D:\\v2ray\\access.log",  // 这是 Windows 系统的路径
    "error": "D:\\v2ray\\error.log"
  },
  "inbounds": [
    {
      "port": 1080,
      "protocol": "socks",
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      },
      "settings": {
        "auth": "noauth"
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "serveraddr.com",
            "port": 16823,  
            "users": [
              {
                "id": "b831381d-6324-4d53-ad4f-8cda48b30811",  
                "alterId": 64
              }
            ]
          }
        ]
      }
    }
  ]
}
```

### 1.1.2. 服务器配置

```javascript
{
  "log": {
    "loglevel": "warning",
    "access": "/var/log/v2ray/access.log", // 这是 Linux 的路径
    "error": "/var/log/v2ray/error.log"
  },
  "inbounds": [
    {
      "port": 16823,
      "protocol": "vmess",   
      "settings": {
        "clients": [
          {
            "id": "b831381d-6324-4d53-ad4f-8cda48b30811",  
            "alterId": 64
          }
        ]
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",  
      "settings": {}
    }
  ]
}
```

依次看 log 的选项：

- loglevel：日志级别，分别有5个，本例中设定的是 warning
  - debug：最详细的日志信息，专用于软件调试
  - info：比较详细的日志信息，可以看到 V2Ray 详细的连接信息
  - warning：警告信息。轻微的问题信息，经我观察 warning 级别的信息大多是网络错误。推荐使用 warning
  - error：错误信息。比较严重的错误信息。当出现 error 时该问题足以影响 V2Ray 的正常运行
  - none：空。不记录任何信息
- access：将访问的记录保存到文件中，这个选项的值是要保存到的文件的路径
- error：将错误的记录保存到文件中，这个选项的值是要保存到的文件的路径
- error、access 字段留空，并且在手动执行 V2Ray 时，V2Ray 会将日志输出在 stdout 即命令行中（terminal、cmd 等），便于排错

**需要注意的一点是，在 json 中，反斜杠 \ 有特殊意义，因此 Windows 操作系统目录的 \ 符号在配置中要使用 \\ 来表示。**

------

## 1.2. 更新历史

- 2018-09-03 Update
- 2018-11-09 跟进 v4.0+ 的配置格式

# 1. 路由功能

本小节将介绍路由功能的使用。V2Ray 的一大特点就是内置了路由功能，用大白话说就是可以根据自己的实际情况制定一些规则来满足自己的上网需求，最简单最常见的就是直连国内网站、拦截特站点以及代理被墙网站。

## 1.1. 路由简介

先简单举几个例子，都是客户端的。

```javascript
{
  "log": {
    "loglevel": "warning",
    "access": "D:\\v2ray\\access.log",
    "error": "D:\\v2ray\\error.log"
  },
  "inbounds": [
    {
      "port": 1080,
      "protocol": "socks",
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      },
      "settings": {
        "auth": "noauth"  
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "serveraddr.com",
            "port": 16823,  
            "users": [
              {
                "id": "b831381d-6324-4d53-ad4f-8cda48b30811",  
                "alterId": 64
              }
            ]
          }
        ]
      }
    }
  ]
}
```

像上面这个配置就是前面 VMess 的客户端配置文件，假如改一下 outbound 的内容，变成这样：

```javascript
{
  "log": {
    "loglevel": "warning",
    "access": "D:\\v2ray\\access.log",
    "error": "D:\\v2ray\\error.log"
  },
  "inbounds": [
    {
      "port": 1080,
      "protocol": "socks",
      "settings": {
        "auth": "noauth"  
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom", //原来是 VMess，现在改成 freedom
      "settings": {
      }
    }
  ]
}
```

如果修改成这个配置重启客户端之后，你会发现这个时候浏览器设不设置代理其实是一样的，像 Google 这类被墙的网站没法访问了，taobao 这种国内网站还是跟平常一样能上。如果是前面的介绍 VMess，数据包的流向是:

```
{浏览器} <--(socks)--> {V2Ray 客户端 inbound <-> V2Ray 客户端 outbound} <--(VMess)-->  {V2Ray 服务器 inbound <-> V2Ray 服务器 outbound} <--(Freedom)--> {目标网站}
```

但因为现在 V2Ray 客户端的 outbound 设成了 freedom，freedom 就是直连，所以呢修改后数据包流向变成了这样：

```
{浏览器} <--(socks)--> {V2Ray 客户端 inbound <-> V2Ray 客户端 outbound} <--(Freedom)--> {目标网站}
```

V2Ray 客户端从 inbound 接收到数据之后没有经过 VPS 中转，而是直接由 freedom 发出去了，所以效果跟直接访问一个网站是一样的。

再来看下面这个:

```javascript
{
  "log":{
    "loglevel": "warning",
    "access": "D:\\v2ray\\access.log",
    "error": "D:\\v2ray\\error.log"
  },
  "inbounds": [
    {
      "port": 1080,
      "protocol": "socks",
      "settings": {
        "auth": "noauth"  
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "blackhole",
      "settings": {
      }
    }
  ]
}
```

这样的配置生效之后，你会发现无论什么网站都无法访问。这是为什么呢？blackhole 是黑洞的意思，在 V2Ray 这里也差不多相当于是一个黑洞，就是说 V2Ray 从 inbound 接收到数据之后发到 outbound，因为 outbound 是 blackhole，来什么吞掉什么，就是不转发到服务器或者目标网站，相当于要访问什么就阻止访问什么。

到这儿为止，总共介绍了 4 种出口协议：用于代理的 VMess 和 Shadowsocks 协议，用于直连的 freedom 协议，以及用于阻止连接的 blackhole 协议。我们可以利用这几种协议再配合路由功能可以灵活地根据自己的需求针对不同网站进行代理、直连或者拦截。举个简单的例子，比较大众的需求是被墙网站走代理，国内网站直连，其他一些不喜欢的则拦截(比如说百度的高精度定位)。

等等！你这里有 VMess、freedom 和 blackhole 3 个出口，难道要运行 3 个 V2Ray 吗？

当然不是！在 V2Ray 的配置中，`outbounds` 是出口协议的集合，你可以在里面放任意多个出口协议，不仅 3 个，300 个都可以。下面给出放 3 个出口协议配置的例子。

```javascript
{
  "log": {
    "loglevel": "warning",
    "access": "D:\\v2ray\\access.log",
    "error": "D:\\v2ray\\error.log"
  },
  "inbounds": [
    {
      "port": 1080,
      "protocol": "socks",
      "settings": {
        "auth": "noauth"  
      }
    }
  ],
  "outbounds": [ 
    {
      "protocol": "vmess", // 出口协议
      "settings": {
        "vnext": [
          {
            "address": "serveraddr.com", // 服务器 IP 地址
            "port": 16823,  // 服务器端口
            "users": [
              {
                "id": "b831381d-6324-4d53-ad4f-8cda48b30811",  // 用户 ID，须与服务器端配置相同
                "alterId": 64
              }
            ]
          }
        ]
      }
    },
    {
      "protocol": "freedom",
      "settings": {}
    },
    {
      "protocol": "blackhole",
      "settings": {}
    }
  ]
}
```

当然这个配置只是包含了多个出口协议而已，在包含多个出口协议的情况下，只会以 outbounds 中的第一个出口作为默认的出口。要达到上面说的被墙网站走代理，国内网站直连，其他特殊网站拦截的效果，还得加入路由功能的配置。关于路由功能的配置见后面两小节。

## 1.2. 更新历史

- 2018-11-09 跟进 v4.0+ 的配置格式

# 1. 国内直连

## 1.1. 配置

### 1.1.1. 客户端

```javascript
{
  "log": {
    "loglevel": "warning",
    "access": "D:\\v2ray\\access.log",
    "error": "D:\\v2ray\\error.log"
  },
  "inbounds": [
    {
      "port": 1080,
      "protocol": "socks",
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      },
      "settings": {
        "auth": "noauth",
        "udp": true
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "serveraddr.com",
            "port": 16823,  
            "users": [
              {
                "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
                "alterId": 64
              }
            ]
          }
        ]
      }
    },
    {
      "protocol": "freedom",
      "settings": {},
      "tag": "direct" //如果要使用路由，这个 tag 是一定要有的，在这里 direct 就是 freedom 的一个标号，在路由中说 direct V2Ray 就知道是这里的 freedom 了
    }    
  ],
  "routing": {
    "domainStrategy": "IPOnDemand",
    "rules": [
      {
        "type": "field",
        "outboundTag": "direct",
        "domain": ["geosite:cn"] // 中国大陆主流网站的域名
      },
      {
        "type": "field",
        "outboundTag": "direct",
        "ip": [
          "geoip:cn", // 中国大陆的 IP
          "geoip:private" // 私有地址 IP，如路由器等
        ]
      }
    ]
  }
}
```

### 1.1.2. 服务器

```javascript
{
  "log": {
    "loglevel": "warning",
    "access": "/var/log/v2ray/access.log",
    "error": "/var/log/v2ray/error.log"
  },
  "inbounds": [
    {
      "port": 16823,
      "protocol": "vmess",    
      "settings": {
        "clients": [
          {
            "id": "b831381d-6324-4d53-ad4f-8cda48b30811"
          }
        ]
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    }
  ]
}
```

## 1.2. 说明

看客户端配置，注意 routing 有一个 domainStrategy， 跟着写就行，当然也可以设成其它的，这里我不说，想知道就看用户手册。重点在 rules，我们要设置的路由规则就放在这里，注意这是一个数组，也就是说可以设置多个路由规则，当访问一个网站，数据包进入 V2Ray 之后路由就会先看看有没有能够匹配的规则，然后执行规则。

在rules 数组中的每个规则由一组大括号`{ }`扩起来。规则中的 type 是固定的(也就是照抄就行)， 两个规则分别有 `"domain": ["geosite:cn"]` 和 `"ip": ["geoip:cn"]`，这两个分别包含了中国大陆主流网站大部分域名和几乎所有的 ip 。两个规则的 outboundTag 都是 direct （outbounds 中 tag 为 direct 的是 freedom）那么如果访问了国内的网站路由就会将这个数据包发往 freedom，也就是直连了。比如说我访问了 qq.com，qq.com 是国内网站包含在 chinasites 里，就会匹配路由规则发往 freedom。

也许有的朋友会觉得奇怪，在这个例子当中路由规则只有国内网站直连，没有关于走代理的规则，但仍然可以访问 google.com、twitter.com 这类等众多被墙的网站的。这因为 `outbounds` 中的第一个出口协议是作为默认的出口，当一个数据包没有匹配的规则时，路由就会把数据包发往默认出口，在本例中 VMess 位于 `outbounds` 中的第一个，即不是访问中国大陆网站的数据包将通过 VPS 代理。

服务器配置与前面 VMess 一样，不再赘述。

------

到这里为止的配置已经可以满足基本的翻墙需求了。但是如果仅仅止步于此，那么也没什么使用 V2Ray 的必要，还不如用 Shadowsocks，毕竟 Shadowsocks 的配置不过 10 行，网上文章又多。

指南到这里还没完结，后面还有许多强大的功能等着我们来挖掘呢。少年，来吧！

## 1.3. 更新历史

- 2018-11-09 跟进 v4.0+ 配置格式

# 1. 广告过滤

## 1.1. 配置

### 1.1.1. 客户端

```javascript
{
  "log": {
    "loglevel": "warning",
    "access": "D:\\v2ray\\access.log",
    "error": "D:\\v2ray\\error.log"
  },
  "inbounds": [
    {
      "port": 1080,
      "protocol": "socks",
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      },
      "settings": {
        "auth": "noauth"
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "serveraddr.com",
            "port": 16823,
            "users": [
              {
                "id": "2b831381d-6324-4d53-ad4f-8cda48b30811",  
                "alterId": 64
              }
            ]
          }
        ]
      }
    },
    {
      "protocol": "freedom",
      "settings": {},
      "tag": "direct"//如果要使用路由，这个 tag 是一定要有的，在这里 direct 就是 freedom 的一个标号，在路由中说 direct V2Ray 就知道是这里的 freedom 了
    },
    {
      "protocol": "blackhole",
      "settings": {},
      "tag": "adblock"//同样的，这个 tag 也是要有的，在路由中说 adblock 就知道是这里的 blackhole（黑洞） 了
    }
  ],
  "routing": {
    "domainStrategy": "IPOnDemand",
    "rules": [
      {
        "domain": [
          "tanx.com",
          "googeadsserving.cn",
          "baidu.com"
        ],
        "type": "field",
        "outboundTag": "adblock"       
      },
      {
        "domain": [
          "amazon.com",
          "microsoft.com",
          "jd.com",
          "youku.com",
          "baidu.com"
        ],
        "type": "field",
        "outboundTag": "direct"
      },
      {
        "type": "field",
        "outboundTag": "direct"，
        "domain": ["geosite:cn"]
      },
      {
        "type": "field",
        "outboundTag": "direct",
        "ip": [
          "geoip:cn",
          "geoip:private"
        ]
      }
    ]
  }
}
```

### 1.1.2. 服务器

```javascript
{
  "log": {
    "loglevel": "warning",
    "access": "/var/log/v2ray/access.log",
    "error": "/var/log/v2ray/error.log"
  },
  "inbounds": [
    {
      "port": 16823,
      "protocol": "vmess",    
      "settings": {
        "clients": [
          {
            "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
            "alterId": 64
          }
        ]
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    }
  ]
}
```

## 1.2. 说明

相对于上小节，在本小节的配置变化只在于客户端配置的 outbounds 和 routing 添加了新的内容，请大家自行比较。

在 routing 中，新添加了两个规则：

```javascript
{
  "domain": [
    "tanx.com",
    "googeadsserving.cn",
    "baidu.com"
  ],
  "type": "field",
  "outboundTag": "adblock"       
},
{
  "domain": [
    "amazon.com",
    "microsoft.com",
    "jd.com",
    "youku.com",
    "baidu.com"
  ],
  "type": "field",
  "outboundTag": "direct"
}
```

在第一个规则中，域名包含有 tanx.com 或 baidu.com 的就会被阻止连接，如果想拦截某些网站，往 adblock 的规则中写想要拦截的域名就可以了。在第二个规则当中，域名中包含有 amazon.com 或 microsoft.com 或 youku.com 或 baidu.com 的会直连。有一个问题大家发现没有，两个规则都有 baidu.com ，那么会执行哪个呢？答案是只会执行第一个（即adblock)，原因是：

1. 规则是放在 routing.rules 这个数组当中，数组的内容是有顺序的，也就是说在这里规则是有顺序的，匹配规则时是从上往下匹配；
2. 当路由匹配到一个规则时就会跳出匹配而不会对之后的规则进行匹配；

关于路由更多内容请参考 [V2Ray 用户手册](https://www.v2ray.com/chapter_02/03_routing.html)

## 1.3. 更新历史

- 2018-11-09 跟进 v4.0+ 配置格式

# 1. 关于路由规则的注意事项

本节记录了一些新手朋友使用 V2Ray 使用路由功能时常范的错误，希望大家能够避免。

## 1.1. 通配符

如果我想让淘宝和京东的域名直连，路由功能的规则写成下面这样的，你觉得这样的规则有问题吗？

```javascript
[
    {
        "type": "field",
        "outboundTag": "direct",
        "domain": [
            "*.taobao.com",
            "*.jd.com"
        ]
    }
]
```

看起来没有什么问题，但事实上，有。如果使用了这样的规则，你会发现根本没有走 direct 直连。很奇怪？这并不奇怪。这是因为你的经验在作祟。在 V2Ray 中，星号 * 不具备通配符的意义，只是一个普通的字符而已，是你以为星号 * 是通配符，这是臆想。如果想要匹配所有子域名的话，可以这么写规则：

```javascript
[
    {
        "type": "field",
        "outboundTag": "direct",
        "domain": [
            "domain:taobao.com",
            "domain:jd.com"
        ]
    }
]
```

`domain:` 代表子域名，如 "domain:taobao.com" 这样一条规则包含了所有 taobao.com 域名及其子域名。

## 1.2. IP & domain

```javascript
[
    {
        "type": "field",
        "outboundTag": "direct",
        "domain": [
            "domain:taobao.com"
        ],
        "ip": [
            "192.168.0.0/16"
        ]
    }
]
```

这样的一个规则的严格来说没有问题，真正的问题在与使用者不理解规则的配置。如果要匹配以上的规则，那么代表这有一个数据包的目标地址域名是 taobao.com 并且 IP 属于 192.168.0.0.1/16。通常情况下这是不可能的，所以你访问淘宝是不会匹配这个规则。如果你要满足域名和 IP 任一条件都能够匹配规则，那么应该这么写：

```javascript
[
    {
        "type": "field",
        "outboundTag": "direct",
        "domain": [
            "domain:taobao.com"
        ]
    }，
    {
        "type": "field",
        "outboundTag": "direct",
        "ip": [
            "192.168.0.0/16"
        ]
    }
]
```

## 1.3. subdomain

## 1.4. regexp

## 1.5. private ip

# 1. 小结

现在对本章作个总结。

## 1.1. 配置文件格式

V2Ray 的配置文件格式就像这样：

```javascript
{
  "log": {},
  "inbounds": [],
  "outbounds": [],
  "routing": {},
  "transport": {},
  "dns": {},
  "reverse": {},
  "policy": {},
  "stats": {},
  "api": {}
}
```

总的来说，V2Ray 的配置有 10 个字段，每个字段都可以进一步展开成具体的配置。这些配置字段当中，本章有涉及到前面 4 项，关于 `dns` 、`transport` 和 `reverse` 将在后文说明。而 `api`、`policy` 和 `stats` 的内容我不考虑出，对这些感兴趣的仔细研究手册吧。

要理解 V2Ray 的工作模式，首先得抛开客户端和服务器的概念(教程中说客户端和服务器是习惯了)，我们更应该以中转节点的概念来理解。 V2Ray 只是一个转发数据的软件，只要它从入口当中接收到数据包，不管 V2Ray 对这些数据包做了什么（加密、解密、协议转换等），到最后肯定是要把这些数据包从出口发出去。每一个运行的 V2Ray 都是一个节点，它从上一个节点接收数据，发送到下一个节点，在这样由多个节点组成的代理链中，首节点和末节点就是我们常说的客户端和服务器。更广义地说，每个节点对于上一个节点来说是服务器，对于下一个节点来说是客户端。

## 1.2. 协议

无论是出口还是入口，我们首先要明确的是协议，只有协议对了才能正常通信。

V2Ray 的传入协议有 HTTP、SOCKS、VMess、Shadowsocks、Dokodemo-door；传出协议有 VMess、Shadowsocks、Blackhole、Freedom、SOCKS。

在 inbounds 和 outbounds 当中，无论使用了什么协议，inbounds 或者 outbounds 的配置格式都是一样的，区别只在于不同的协议对应的 settings 内容不一样。

------

## 1.3. 更新历史

- 2018-04-05 补充
- 2018-11-09 跟进 v4.0+ 配置格式



# 1. 高级篇

恭喜大家来到高级篇。

使用基础篇当中的配置案例已经能够满足基本的科学上网需求，但 V2Ray 提供了许多额外的功能，可以带来更好的上网体验。在本篇当中，将针对某个功能简要介绍，并给出关键配置，因此可能不是完整的，也不会像基础篇那样详细，只会在关键之处作一些必要的介绍。

V2Ray 的相比其它工具有一大优点是可以自行选择传输层的形式，也就是说 V2Ray 服务器和客户端之间的传输的数据包形式我们是可以选择的。如我们可以选择伪装成 HTTP(TCP)流量，如果使用了 mKCP 也可以伪装成 BT 下载、视频通话、微信视频通话。也可以选择使用 WebSokcs 或者 TLS。以上这个都是传输层的配置决定的。

V2Ray 中传输层配置在 transport 里设定，也可以在 inbound/outbound 中的 streamSettings 设定。这两者的区别是 inbound/outbound 的 streamSettings 只对当前的 inbound/outbound 有效(分连接配置)，不影响其它的 inbound/outbound 的传输层配置，而 transport 是全局的，对整个配置所有的 inbound 和 outbound 都有效(全局配置)，如果一个 inbound/outbound 中设定了 streamSettings，transport 的全局设定不会影响这个 inbound/outbound。

在本篇当中，大部分内容都涉及到了传输层，关于这部分内容使用的是 inbound/outbound 的 streamSettings(分连接配置)，同时也建议大家使用分连接配置。因为通常情况下我们会有在不同的 inbound/outbound 中使用不同的传输层配置。

# 1. Mux

Mux 意为多路复用(multiplexing)，在目前的科学上网工具中仅 V2Ray 有此功能(2018-03-15注：也有其他软件实现了类似的功能)。它能够将多条 TCP 连接合并成一条，节省资源，提高并发能力。

听众：呃？什么鬼？

好吧，翻译成人话就是：

从前，有一个人叫小白，他是骑行爱好者，还是网购狂人、DIY玩家，因此手中有点闲钱总会网购，也喜欢自己买配件组装自行车。有一次他组装自行车，在网上骑行之家买了头盗、手套、码表，在x诺专卖店买了指拨、变速器，在x特专卖买了车架，在xx车行买了刹车、踏板、坐垫，在xxx买了轮组、曲柄……

```
四天后……
9 点小白手机响了，接通，小白：喂，你好。对方：你好，申x快递，来取一下包裹。小白兴兴冲地取快递了。    
20 分钟后，小白：喂，你好。对方：你好，韵x，过来取快递。小白又去了。    
又过 15 分钟，小白：喂，你好。对方：你好，天x，来取快递。小白又去了。    
又过半个小时，小白：什么快递？对方：圆x，快点来。小白心里：我X。    
10 分钟后……
```

如果是你是小白，你累不累？ 电脑也差不多，但要干的活要小白多得多：

```
浏览器：我要看 V2Ray 配置指南。
电脑：好，我发起一条 TCP 连接。
Telegram：我要进 V2Ray 的 Telegram 群向大佬学习。
电脑：好，发起了连接。
浏览器：我要看 V2Ray 的手册。
电脑：好。
浏览器：我要 Google 搜索 V2Ray 的教程。
电脑：好。
浏览器：我要……
```

如果正常的上网连接可以使用上面小白的例子类比的话，那么，V2Ray 的 Mux 就是：

小黑也与小白一样自行组装自行车，也是网购配件，但他无论什么东西都从xx车行这店里买。

```
4 天后，小黑接起电话：你好。
对方：你好，顺x，来取一下快递。
小黑顺路买了瓶饮料：大哥，天气这么热，喝点水解解渴。嘿嘿，这箱子太沉，辛苦一下帮帮我搬到屋里吧。
```

Mux 实质上不能提高网速，但对并发连接比较有效，如浏览图片较多的网页，看直播等。从使用效果来说，V2Ray 的 Mux 应该类似于 Shadowsocks 的 TFO(TCP Fast Open)，因为两者的目的都是减小握手时间，只是实现方式不一样。只是 TFO 要设置系统内核才能打开，而 Mux 是纯粹在软件层面上实现，从配置难易度上 V2Ray 较好一些。（2018-09-19 注：刚更新这段话没多久，V2Ray 就加入了对 TFO 的支持，感觉要学不动了～）

## 1.1. 配置

Mux 只需在客户端开启，服务器会自动识别，所以只给客户端的配置。也就是只要在 outbound 或 outboundDetour 加入 `"mux": {"enabled": true}` 即可：

```javascript
{
  "inbounds": [
    {
      "port": 1080, // 监听端口
      "protocol": "socks", // 入口协议为 SOCKS 5
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      },
      "settings": {
        "auth": "noauth"  // 不认证
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vmess", // 出口协议
      "settings": {
        "vnext": [
          {
            "address": "serveraddr.com", // 服务器地址，请修改为你自己的服务器 ip 或域名
            "port": 16823,  // 服务器端口
            "users": [
              {
                "id": "b831381d-6324-4d53-ad4f-8cda48b30811",  // 用户 ID，必须与服务器端配置相同
                "alterId": 64 // 此处的值也应当与服务器相同
              }
            ]
          }
        ]
      },
      "mux": {"enabled": true}
    }
  ]
}
```

## 1.2. 更新历史

- 2018-08-30 修改排版、描述
- 2018-11-17 V4.0+ 配置

# 1. mKCP

V2Ray 引入了 [KCP](https://github.com/skywind3000/kcp) 传输协议，并且做了一些不同的优化，称为 mKCP。如果你发现你的网络环境丢包严重，可以考虑一下使用 mKCP。由于快速重传的机制，相对于常规的 TCP 来说，mKCP 在高丢包率的网络下具有更大的优势，也正是因为此， mKCP 明显会比 TCP 耗费更多的流量，所以请酌情使用。要了解的一点是，mKCP 与 KCPTUN 同样是 KCP 协议，但两者并不兼容。

在此我想纠正一个概念。基本上只要提起 KCP 或者 UDP，大家总会说”容易被 Qos“。Qos 是一个名词性的短语，中文意为服务质量，试想一下，你跟人家说一句”我的网络又被服务质量了“是什么感觉。其次，哪怕名词可以动词化，这么使用也是不合适的，因为 Qos 区分网络流量优先级的，就像马路上划分人行道、非机动车道、快车道、慢车道一样，哪怕你牛逼到运营商送你一条甚至十条专线，是快车道中的快车道，这也是 Qos 的结果。

## 1.1. 配置

mKCP 的配置比较简单，只需在服务器的 inbounds 和 客户端的 outbounds 添加一个 streamSettings 并设置成 mkcp 即可。

### 1.1.1. 服务器配置

```javascript
{
  "inbounds": [
    {
      "port": 16823,
      "protocol": "vmess",
      "settings": {
        "clients": [
          {
            "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
            "alterId": 64
          }
        ]
      },
      "streamSettings": {
        "network": "mkcp", //此处的 mkcp 也可写成 kcp，两种写法是起同样的效果
        "kcpSettings": {
          "uplinkCapacity": 5,
          "downlinkCapacity": 100,
          "congestion": true,
          "header": {
            "type": "none"
          }
        }
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    }
  ]
}
```

### 1.1.2. 客户端配置

```javascript
{
  "inbounds": [
    {
      "port": 1080,
      "protocol": "socks",
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
    },
      "settings": {
        "auth": "noauth"
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "serveraddr.com",
            "port": 16823,
            "users": [
              {
                "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
                "alterId": 64
              }
            ]
          }
        ]
      },
      "streamSettings": {
        "network": "mkcp",
        "kcpSettings": {
          "uplinkCapacity": 5,
          "downlinkCapacity": 100,
          "congestion": true,
          "header": {
            "type": "none"
          }
        }
      }
    }
  ]
}
```

### 1.1.3. 说明

在上面的配置当中，与之前相比主要的变化在于多了一个 streamSettings，包含有不少参数：

- `network`: 网络的选择，要像上面的配置写成 kcp 或 mkcp 才会启用 mKCP

- ```
  kcpSettings
  ```

  : 包含一些关于 mKCP 设置的参数，有

  - `uplinkCapacity`: 上行链路容量，将决定 V2Ray 向外发送数据包的速率。单位为 MB

  - `downlinkCapacity`：下行链路容量，将决定 V2Ray 接收数据包的速率。单位同样是 MB

  - ```
    header
    ```

    ：对于数据包的伪装

    - `type`：要伪装成的数据包类型

客户端的上行对于服务器来说是下行，同样地客户端的下行是服务器的上行，mKCP 设置当中服务器和客户端都有 uplinkCapacity 和 downlinkCapacity，所以客户端的上传速率由服务器的 downlinkCapacity 和客户端的 uplinkCapacity 中的最小值决定，客户端的下载速率也是同样的道理。因此，建议将服务器和客户端的 downlinkCapacity 设成一个很大的值，然后分别修改两端的 uplinkCapacity 以调整上下行速率。

还有一个 header 参数可以对 mKCP 进行伪装，这是 mKCP 的一个优势。具体的伪装类型在 type 参数设置，type 可以设置成 utp、srtp、wechat-video、dtls、wireguard 或者 none，这几个分别将 mKCP 数据伪装成 BT 下载、视频通话、微信视频通话、dtls、wireguard(一种新型 VPN)以及不进行伪装。**这里的 type 参数，客户端与服务器要一致。还有要时刻记住伪装仅仅是伪装。**

至于上述配置里有但是我没有说明的参数，是 V2Ray 的默认值，我个人建议是保持默认。如果你需要了解或者修改，请参考手册。

## 1.2. 更新历史

- 2018-03-17 Update
- 2018-08-30 Update
- 2018-11-17 V4.0+ 配置

# 1. 动态端口

V2Ray 提供了一个叫动态端口的功能。顾名思义，就是可以动态变化通信端口，该功能的初衷是为了应对电信服务运营商可能会对长时间大流量的单个端口进行限速。也许是用的人比较少，到目前为止没有证据可以动态端口对于科学上网是加分项还是减分项。

## 1.1. 基本动态端口

服务器 inbound 的端口作为主端口，在 inboundDetour 开动态监听的端口，客户端不用额外设定，客户端会先与服务器的主端口通信协商下一个使用的端口号。

### 1.1.1. 服务器配置

```javascript
{
  "inbounds":[
  { //主端口配置
      "port": 37192,
      "protocol": "vmess",
      "settings": {
        "clients": [
          {
            "id": "d17a1af7-efa5-42ca-b7e9-6a35282d737f",
            "alterId": 64
          }
        ],
        "detour": { //绕行配置，即指示客户端使用 dynamicPort 的配置通信
          "to": "dynamicPort"   
        }
      }
    },
    {
      "protocol": "vmess",
      "port": "10000-20000", // 端口范围
      "tag": "dynamicPort",  // 与上面的 detour to 相同
      "settings": {
        "default": {
          "alterId": 64
        }
      },
      "allocate": {            // 分配模式
        "strategy": "random",  // 随机开启
        "concurrency": 2,      // 同时开放两个端口,这个值最大不能超过端口范围的 1/3
        "refresh": 3           // 每三分钟刷新一次
      }
    }
  ]
}
```

### 1.1.2. 客户端配置

```javascript
{
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "1.2.3.4",
            "port": 37192,
            "users": [
              {
                "id": "d17a1af7-efa5-42ca-b7e9-6a35282d737f",
                "alterId": 64
              }
            ]
          }
        ]
      }
    }
  ]
}
```

## 1.2. 动态端口使用 mKCP

在对应的 inbounds 和 outbounds 加入 streamSettings 并将 network 设置为 kcp 即可。

### 1.2.1. 服务器配置

```javascript
{
  "inbounds": [
    {
      "port": 37192,
      "protocol": "vmess",
      "settings": {
        "clients": [
          {
            "id": "d17a1af7-efa5-42ca-b7e9-6a35282d737f",
            "level": 1,
            "alterId": 64
          }
        ],
        "detour": {        
          "to": "dynamicPort"   
        }
      },
      "streamSettings": {
        "network": "kcp"
      }
    },
    {
      "protocol": "vmess",
      "port": "10000-20000", // 端口范围
      "tag": "dynamicPort",       
      "settings": {
        "default": {
          "level": 1,
          "alterId": 32
        }
      },
      "allocate": {            // 分配模式
        "strategy": "random",  // 随机开启
        "concurrency": 2,      // 同时开放两个端口
        "refresh": 3           // 每三分钟刷新一次
      },
      "streamSettings": {
        "network": "kcp"
      }
    }
  ]
}
```

### 1.2.2. 客户端配置

```javascript
{
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "1.2.3.4",
            "port": 37192,
            "users": [
              {
                "id": "d17a1af7-efa5-42ca-b7e9-6a35282d737f",
                "alterId": 64
              }
            ]
          }
        ]
      },
      "streamSettings": {
        "network": "kcp"
      }
    }
  ]
}
```

------

## 1.3. 更新历史

- 2018-01-06 删除错误且不必要的部分
- 2018-11-17 V4.0+ 配置

# 1. 代理转发

V2Ray 提供了代理转发功能，利用它可以实现中转（在没有中转服务器操作权限的情况下）。

## 1.1. 基本代理转发

使用代理转发可以实现由一个 Shadowsocks 服务器或者 V2Ray(VMess) 服务器来中转你的网络流量，并且中转服务器只能看到你加密的数据而不知道原始的数据是什么。

以下面的配置说明，它的工作原理是：

1. 你在 Twitter 发了个帖子 f**k GFW，由 V2Ray 代理
2. V2Ray 客户端收到浏览器发出的 f**k GFW 的帖子后，首先由对其进行加密(VMess，id: b12614c5-5ca4-4eba-a215-c61d642116ce,目的服务器: 1.1.1.1:8888)
3. 加密后数据包将被转到 transit 这个 outbound 中，在这里数据包又会加密一次(Shadowsocks, password: password, 服务器: 2.2.2.2:1024)
4. 两次加密后的数据包被发送到了 Shadowsocks 服务器，该服务器收到后解包后得到仍是加密的数据包（步骤 2 中加密后的数据包），然后将数据包发到 VMess 服务器。即便这个 Shadowsocks 服务器的主人是个偷窥狂魔，他也没办法看到你的原始数据。
5. VMess 服务器收到 Shadowsocks 服务器发来的数据包，解密得到原始的数据包，然后把你这个帖子发到 Twitter 的网站中。

只要第 5 步中的服务器是自己掌控的就不用担心别人看到你的上网的内容。

客户端：

```javascript
{
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": { // settings 的根据实际情况修改
        "vnext": [
          {
            "address": "1.1.1.1",
            "port": 8888,
            "users": [
              {
                "alterId": 64,
                "id": "b12614c5-5ca4-4eba-a215-c61d642116ce"
              }
            ]
          }
        ]
      },
      "proxySettings": {
          "tag": "transit"  // 这里的 tag 必须跟作为代理 VPS 的 tag 一致，这里设定的是 "transit"
        }
    },
    {
      "protocol": "shadowsocks",
      "settings": {
        "servers": [
          {
            "address": "2.2.2.2",
            "method": "aes-256-cfb",
            "ota": false,
            "password": "password",
            "port": 1024
          }
        ]
      },
      "tag": "transit"
    }
  ]
}
```

## 1.2. 链式代理转发

如果你有多个 Shadowsocks 或 VMess 账户，那么你可以这样:

```javascript
{
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": { // settings 的根据实际情况修改
        "vnext": [
          {
            "address": "1.1.1.1",
            "port": 8888,
            "users": [
              {
                "alterId": 64,
                "id": "b12614c5-5ca4-4eba-a215-c61d642116ce"
              }
            ]
          }
        ]
      },
      "tag": "DOUS",
      "proxySettings": {
          "tag": "DOSG"  
        }
    },
    {
      "protocol": "shadowsocks",
      "settings": {
        "servers": [
          {
            "address": "2.2.2.2",
            "method": "aes-256-cfb",
            "ota": false,
            "password": "password",
            "port": 1024
          }
        ]
      },
      "tag": "AliHK"
    },
    {
      "protocol": "shadowsocks",
      "settings": {
        "servers": [
          {
            "address": "3.3.3.3",
            "method": "aes-256-cfb",
            "ota": false,
            "password": "password",
            "port": 3442
          }
        ]
      },
      "tag": "AliSG",
      "proxySettings": {
          "tag": "AliHK"  
      }
    },
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "4.4.4.4",
            "port": 8462,
            "users": [
              {
                "alterId": 64,
                "id": "b27c24ab-2b5a-433e-902c-33f1168a7902"
              }
            ]
          }
        ]
      },
      "tag": "DOSG",
      "proxySettings": {
          "tag": "AliSG"  
      }
    },
  ]
}
```

那么数据包经过的节点依次为： PC -> AliHK -> AliSG -> DOSG -> DOUS -> 目标网站

这样的代理转发形成了一条链条，我称之为链式代理转发。

**注意：如果你打算配置(动态)链式代理转发，应当明确几点：**

- `性能`。链式代理使用了多个节点，可能会造成延时、带宽等网络性能问题，并且客户端对每一个加解密的次数取决于代理链的长度，理论上也会有一定的影响。
- `安全`。前文提到，代理转发会一定程度上提高安全性，但安全取决于最弱一环，并不意味着代理链越长就会越安全。如果你需要匿名，请考虑成熟的匿名方案。 另外，使用了代理转发 streamSettings 会失效，即只能是非 TLS、无 HTTP 伪装的 TCP 传输协议。

## 1.3. 更新历史

- 2018-03-17 Update
- 2018-07-08 Update
- 2018-11-17 V4.0+ 配置

# 1. HTTP 伪装

（**2018-03-16 注：个人建议不要使用 HTTP 伪装**） V2Ray 自 v2.5 版本开始提供 HTTP 伪装功能，后经作者不断完善，到现在已经非常成熟稳定了。V2Ray 的 HTTP 伪装功能可以可以将 V2Ray 的流量伪装成正常的 HTTP 协议的。这里给出一个 HTTP 伪装的服务器端与客户端配置文件示例。

配置中关于 HTTP 头字段的内容及含义，[Wikipedia](https://zh.wikipedia.org/wiki/HTTP头字段列表) 有简要的说明，可参阅。

## 1.1. 配置

从 V2Ray 的实现角度来说，使用 HTTP 伪装的同时完全可以使用动态端口。但我个人并不建议这么做，因为从实际情况来看，基本上不会有人在一个服务器上开使用多个端口的 Web 服务。如果你觉得 HTTP 伪装的配置过于复杂不懂得如何修改，那请直接使用下面的配置即可。

### 1.1.1. 服务器

```javascript
{
  "log" : {
    "access": "/var/log/v2ray/access.log",
    "error": "/var/log/v2ray/error.log",
    "loglevel": "warning"
  },
  "inbounds": [
    {
      "port": 80, //推荐80端口，更好地迷惑防火墙（好吧实际上并没有什么卵用
      "protocol": "vmess",
      "settings": {
        "clients": [
          {
            "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
            "level": 1,
            "alterId": 64
          }
        ]
      },
      "streamSettings": {
        "network": "tcp",
        "tcpSettings": {
          "header": { // header 这一项是关于数据包伪装的设置，可自定义合理的内容，但要确保服务器与客户端一致
            "type": "http",
            "response": {
              "version": "1.1",
              "status": "200",
              "reason": "OK",
              "headers": {
                "Content-Type": ["application/octet-stream", "application/x-msdownload", "text/html", "application/x-shockwave-flash"],
                "Transfer-Encoding": ["chunked"],
                "Connection": ["keep-alive"],
                "Pragma": "no-cache"
              }
            }
          }
        }
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    },
    {
      "protocol": "blackhole",
      "settings": {},
      "tag": "blocked"
    }
  ],
  "routing": {
    "strategy": "rules",
    "settings": {
      "rules": [
        {
          "type": "field",
          "ip": [
            "geoip:private"
          ],
          "outboundTag": "blocked"
        }
      ]
    }
  }
}
```

### 1.1.2. 客户端

```javascript
{
  "log": {
    "loglevel": "warning"
  },
  "inbounds": [
    {
      "port": 1080,
      "protocol": "socks",
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      },
      "settings": {
        "auth": "noauth"
      }
    }
  ],
  "outbound": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "serveraddr.com",
            "port": 80,
            "users": [
              {
                "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
                "alterId": 64
              }
            ]
          }
        ]
      },
      "streamSettings": {
        "network": "tcp",
        "tcpSettings": {
          "header": {  //这里的 header 要与服务器保持一致
            "type": "http",
            "request": {
              "version": "1.1",
              "method": "GET",
              "path": ["/"],
              "headers": {
                "Host": ["www.cloudflare.com", "www.amazon.com"],
                "User-Agent": [
                  "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36",
                          "Mozilla/5.0 (iPhone; CPU iPhone OS 10_0_2 like Mac OS X) AppleWebKit/601.1 (KHTML, like Gecko) CriOS/53.0.2785.109 Mobile/14A456 Safari/601.1.46"
                ],
                "Accept-Encoding": ["gzip, deflate"],
                "Connection": ["keep-alive"],
                "Pragma": "no-cache"
              }
            }
          }
        }
      }
    },
    {
      "protocol": "freedom",
      "settings": {},
      "tag": "direct"
    }
  ],
  "routing": {
    "strategy": "rules",
    "settings": {
      "domainStrategy": "IPIfNonMatch",
      "rules": [
        {
          "type": "field",
          "ip": [
            "geoip:private"
          ],
          "outboundTag": "direct"
        },
        {
          "type": "chinasites",
          "outboundTag": "direct"
        },
        {
          "type": "chinaip",
          "outboundTag": "direct"
        }
      ]
    }
  }
}
```

------

## 1.2. 更新历史

- 2017-08-05 删掉部分不必要的配置
- 2018-03-16 Update
- 2019-01-13 V4.0+配置格式

#  1. TLS

从 v1.19 起引入了 TLS，TLS 中文译名是传输层安全，如果你没听说过，请 Google 了解一下。以下给出些我认为介绍较好的文章链接：

[SSL/TLS协议运行机制的概述](http://www.ruanyifeng.com/blog/2014/02/ssl_tls.html)

[传输层安全协议](https://zh.wikipedia.org/wiki/傳輸層安全協議)

## 1.1. 注册一个域名

如果已经注册有域名了可以跳过。 TLS 需要一个域名，域名有免费的和有付费的，如果你不舍得为一个域名每年花点钱，用个免费域名也可以，但总体来说付费的会优于免费的。为了方便，在本文中我就忽略如何注册购买域名了。关于如何获取域名，具体搜索相关文章教程。

**注册好域名之后务必记得添加一个 A 记录指向你的 VPS!**

**以下假设注册的域名为 mydomain.me，请将之替换成自己的域名。**

## 1.2. 证书生成

TLS 是证书认证机制，所以使用 TLS 需要证书，证书也有免费付费的，同样的这里使用免费证书，证书认证机构为 [Let's Encrypt](https://letsencrypt.org/)。 证书的生成有许多方法，这里使用的是比较简单的方法：使用 [acme.sh](https://github.com/Neilpang/acme.sh) 脚本生成，本部分说明部分内容参考于[acme.sh README](https://github.com/Neilpang/acme.sh/blob/master/README.md)。

证书有两种，一种是 ECC 证书（内置公钥是 ECDSA 公钥），一种是 RSA 证书（内置 RSA 公钥）。简单来说，同等长度 ECC 比 RSA 更安全,也就是说在具有同样安全性的情况下，ECC 的密钥长度比 RSA 短得多（加密解密会更快）。但问题是 ECC 的兼容性会差一些，Android 4.x 以下和 Windows XP 不支持。只要您的设备不是非常老的老古董，强烈建议使用 ECC 证书。

以下将给出这两类证书的生成方法，请大家根据自身的情况自行选择其中一种证书类型。

证书生成只需在服务器上操作。

### 1.2.1. 安装 acme.sh

执行以下命令，acme.sh 会安装到 ~/.acme.sh 目录下。

```
$ curl  https://get.acme.sh | sh
% Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                               Dload  Upload   Total   Spent    Left  Speed
100   671  100   671    0     0    680      0 --:--:-- --:--:-- --:--:--   679
% Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                               Dload  Upload   Total   Spent    Left  Speed
100  112k  100  112k    0     0   690k      0 --:--:-- --:--:-- --:--:--  693k
[Fri 30 Dec 01:03:32 GMT 2016] Installing from online archive.
[Fri 30 Dec 01:03:32 GMT 2016] Downloading https://github.com/Neilpang/acme.sh/archive/master.tar.gz
[Fri 30 Dec 01:03:33 GMT 2016] Extracting master.tar.gz
[Fri 30 Dec 01:03:33 GMT 2016] Installing to /home/user/.acme.sh
[Fri 30 Dec 01:03:33 GMT 2016] Installed to /home/user/.acme.sh/acme.sh
[Fri 30 Dec 01:03:33 GMT 2016] Installing alias to '/home/user/.profile'
[Fri 30 Dec 01:03:33 GMT 2016] OK, Close and reopen your terminal to start using acme.sh
[Fri 30 Dec 01:03:33 GMT 2016] Installing cron job
no crontab for user
no crontab for user
[Fri 30 Dec 01:03:33 GMT 2016] Good, bash is found, so change the shebang to use bash as preferred.
[Fri 30 Dec 01:03:33 GMT 2016] OK
[Fri 30 Dec 01:03:33 GMT 2016] Install success!
```

安装成功后执行 `source ~/.bashrc` 以确保脚本所设置的命令别名生效。

如果安装报错，那么可能是因为系统缺少 acme.sh 所需要的依赖项，acme.sh 的依赖项主要是 netcat(nc)，我们通过以下命令来安装这些依赖项，然后重新安装一遍 acme.sh:

```
$ sudo apt-get -y install netcat
```

### 1.2.2. 使用 acme.sh 生成证书

#### 证书生成

执行以下命令生成证书：

以下的命令会临时监听 80 端口，请确保执行该命令前 80 端口没有使用

```
$ sudo ~/.acme.sh/acme.sh --issue -d mydomain.me --standalone -k ec-256
[Fri Dec 30 08:59:12 HKT 2016] Standalone mode.
[Fri Dec 30 08:59:12 HKT 2016] Single domain='mydomain.me'
[Fri Dec 30 08:59:12 HKT 2016] Getting domain auth token for each domain
[Fri Dec 30 08:59:12 HKT 2016] Getting webroot for domain='mydomain.me'
[Fri Dec 30 08:59:12 HKT 2016] _w='no'
[Fri Dec 30 08:59:12 HKT 2016] Getting new-authz for domain='mydomain.me'
[Fri Dec 30 08:59:14 HKT 2016] The new-authz request is ok.
[Fri Dec 30 08:59:14 HKT 2016] mydomain.me is already verified, skip.
[Fri Dec 30 08:59:14 HKT 2016] mydomain.me is already verified, skip http-01.
[Fri Dec 30 08:59:14 HKT 2016] mydomain.me is already verified, skip http-01.
[Fri Dec 30 08:59:14 HKT 2016] Verify finished, start to sign.
[Fri Dec 30 08:59:16 HKT 2016] Cert success.
-----BEGIN CERTIFICATE-----
MIIEMTCCAxmgAwIBAgISA1+gJF5zwUDjNX/6Xzz5fo3lMA0GCSqGSIb3DQEBCwUA
MEoxCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1MZXQncyBFbmNyeXB0MSMwIQYDVQQD
ExpMZXQncyBFbmNyeXB0IEF1dGhvcml0eSBYMzAeFw0xNjEyMjkyMzU5MDBaFw0x
NzAzMjkyMzU5MDBaMBcxFTATBgNVBAMTDHdlYWtzYW5kLmNvbTBZMBMGByqGSM49
****************************************************************
4p40tm0aMB837XQ9jeAXvXulhVH/7/wWZ8/vkUUvuHSCYHagENiq/3DYj4a85Iw9
+6u1r7atYHJ2VwqSamiyTGDQuhc5wdXIQxY/YQQqkAmn5tLsTZnnOavc4plANT40
zweiG8vcIvMVnnkM0TSz8G1yzv1nOkruN3ozQkLMu6YS7lk/ENBN7DBtYVSmJeU2
VAXE+zgRaP7JFOqK6DrOwhyE2LSgae83Wq/XgXxjfIo1Zmn2UmlE0sbdNKBasnf9
gPUI45eltrjcv8FCSTOUcT7PWCa3
-----END CERTIFICATE-----
[Fri Dec 30 08:59:16 HKT 2016] Your cert is in  /root/.acme.sh/mydomain.me_ecc/mydomain.me.cer
[Fri Dec 30 08:59:16 HKT 2016] Your cert key is in  /root/.acme.sh/mydomain.me_ecc/mydomain.me.key
[Fri Dec 30 08:59:16 HKT 2016] The intermediate CA cert is in  /root/.acme.sh/mydomain.me_ecc/ca.cer
[Fri Dec 30 08:59:16 HKT 2016] And the full chain certs is there:  /root/.acme.sh/mydomain.me_ecc/fullchain.cer
```

`-k` 表示密钥长度，后面的值可以是 `ec-256` 、`ec-384`、`2048`、`3072`、`4096`、`8192`，带有 `ec` 表示生成的是 ECC 证书，没有则是 RSA 证书。在安全性上 256 位的 ECC 证书等同于 3072 位的 RSA 证书。

#### 证书更新

由于 Let's Encrypt 的证书有效期只有 3 个月，因此需要 90 天至少要更新一次证书，acme.sh 脚本会每 60 天自动更新证书。也可以手动更新。

手动更新 ECC 证书，执行：

```
$ sudo ~/.acme.sh/acme.sh --renew -d mydomain.com --force --ecc
```

如果是 RSA 证书则执行：

```
$ sudo ~/.acme.sh/acme.sh --renew -d mydomain.com --force
```

**由于本例中将证书生成到 /etc/v2ray/ 文件夹，更新证书之后还得把新证书生成到 /etc/v2ray。**

### 1.2.3. 安装证书和密钥

#### ECC 证书

将证书和密钥安装到 /etc/v2ray 中：

```
$ sudo ~/.acme.sh/acme.sh --installcert -d mydomain.me --fullchainpath /etc/v2ray/v2ray.crt --keypath /etc/v2ray/v2ray.key --ecc
```

#### RSA 证书

```
$ sudo ~/.acme.sh/acme.sh --installcert -d mydomain.me --fullchainpath /etc/v2ray/v2ray.crt --keypath /etc/v2ray/v2ray.key
```

**注意：无论什么情况，密钥(即上面的v2ray.key)都不能泄漏，如果你不幸泄漏了密钥，可以使用 acme.sh 将原证书吊销，再生成新的证书，吊销方法请自行参考 acme.sh 的手册**

## 1.3. 配置 V2Ray

### 1.3.1. 服务器

```javascript
{
  "inbounds": [
    {
      "port": 443, // 建议使用 443 端口
      "protocol": "vmess",    
      "settings": {
        "clients": [
          {
            "id": "23ad6b10-8d1a-40f7-8ad0-e3e35cd38297",  
            "alterId": 64
          }
        ]
      },
      "streamSettings": {
        "network": "tcp",
        "security": "tls", // security 要设置为 tls 才会启用 TLS
        "tlsSettings": {
          "certificates": [
            {
              "certificateFile": "/etc/v2ray/v2ray.crt", // 证书文件
              "keyFile": "/etc/v2ray/v2ray.key" // 密钥文件
            }
          ]
        }
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    }
  ]
}
```

### 1.3.2. 客户端

```javascript
{
  "inbounds": [
    {
      "port": 1080,
      "protocol": "socks",
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      },
      "settings": {
        "auth": "noauth"
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "mydomain.me", // tls 需要域名，所以这里应该填自己的域名
            "port": 443,
            "users": [
              {
                "id": "23ad6b10-8d1a-40f7-8ad0-e3e35cd38297",
                "alterId": 64
              }
            ]
          }
        ]
      },
      "streamSettings": {
        "network": "tcp",
        "security": "tls" // 客户端的 security 也要设置为 tls
      }
    }
  ]
}
```

## 1.4. 验证

一般来说，按照以上步骤操作完成，V2Ray 客户端能够正常联网说明 TLS 已经成功启用。但要是有个可靠的方法来验证是否正常开启 TLS 无疑更令人放心。 验证的方法有很多，我仅介绍一种小白化一点的，便是 [Qualys SSL Labs's SSL Server Test](https://www.ssllabs.com/ssltest/index.html)。

**注意：使用 Qualys SSL Labs's SSL Server Test 要求使用 443 端口，意味着你服务器配置的 inbound.port 应当是 443**

打开 [Qualys SSL Labs's SSL Server Test](https://www.ssllabs.com/ssltest/index.html)，在 Hostname 中输入你的域名，点提交，过一会结果就出来了。![img](https://toutyrater.github.io/resource/images/tls_test1.png)

![img](https://toutyrater.github.io/resource/images/tls_test2.png)这是对于你的 TLS/SSL 的一个总体评分，我这里评分为 A，看来还不错。有这样的界面算是成功了。

![img](https://toutyrater.github.io/resource/images/tls_test3.png)这是关于证书的信息。从图中可以看出，我的这个证书有效期是从 2016 年 12 月 27 号到 2017 年的 3 月 27 号，密钥是 256 位的 ECC，证书签发机构是 Let's Encrypt，重要的是最后一行，`Trusted` 为 `Yes`，表明我这个证书可信。

## 1.5. 温馨提醒

**V2Ray 的 TLS 不是伪装或混淆，这是完整、真正的 TLS。因此才需要域名和证书。后文提到的 WS(WebSocket) 也不是伪装。**

------

## 1.6. 更新历史

- 2017-08-06 加点提醒
- 2017-12-31 修正文字错误
- 2018-04-05 Update
- 2018-11-17 V4.0+ 配置

# 1. WebSocket

WebSocket 的配置其实很简单，就跟 mKCP 一样把 network 一改就行了。话不多说，直接上配置。

## 1.1. 配置

### 1.1.1. 服务器配置

```javascript
{
  "inbounds": [
    {
      "port": 16823,
      "protocol": "vmess",
      "settings": {
        "clients": [
          {
            "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
            "alterId": 64
          }
        ]
      },
      "streamSettings": {
        "network":"ws"
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    }
  ]
}
```

### 1.1.2. 客户端配置

```javascript
{
  "inbounds": [
    {
      "port": 1080,
      "protocol": "socks",
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      },
      "settings": {
        "auth": "noauth"
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "serveraddr.com",
            "port": 16823,
            "users": [
              {
                "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
                "alterId": 64
              }
            ]
          }
        ]
      },
      "streamSettings":{
        "network":"ws"
      }
    }
  ]
}
```

## 1.2. 更新历史

- 2018-11-17 V4.0+ 配置

# 1. WebSocket+TLS+Web

前文分别提到过 TLS 和 WebSocket 的配置方法，而本文搭配 Web 服务并同时实现 TLS 和 WebSocket。关于 Web 的软件本文给出了 Nginx，Caddy 和 Apache 三个例子，三选一即可，也可以选用其它的软件。

很多新手一接触 V2Ray 就想搞 WebSocket+TLS+Web 或 WebSocket+TLS+Web+CDN，我就想问 ssh 和 vim/nano 用利索了没，步子这么大不怕扯到蛋吗？使用 Nginx / Caddy / Apache 是因为 VPS 已经有 Nginx / Caddy / Apache 可以将 V2Ray 稍作隐藏，使用 WebSocket 是因为搭配 Nginx / Caddy / Apache 只能用 WebSocket，使用 TLS 是因为可以流量加密，看起来更像 HTTPS。 也许 WebSocket+TLS+Web 的配置组合相对较好，但不意味着这样的配置适合任何人。因为本节涉及 Nginx / Caddy / Apache，只给出了配置示例而不讲具体使用方法，也就是说你在阅读本节内容前得会使用这三个软件的其中之一，如果你还不会，请自行 Google。

注意: V2Ray 的 Websocket+TLS 配置组合并不依赖 Nginx / Caddy / Apache，只是能与其搭配使用而已，没有它们也可以正常使用。

## 1.1. 配置

### 1.1.1. 服务器配置

这次 TLS 的配置将写入 Nginx / Caddy / Apache 配置中，由这些软件来监听 443 端口（443 比较常用，并非 443 不可），然后将流量转发到 V2Ray 的 WebSocket 所监听的内网端口（本例是 10000），V2Ray 服务器端不需要配置 TLS。

#### 服务器 V2Ray 配置

```javascript
{
  "inbounds": [
    {
      "port": 10000,
      "listen":"127.0.0.1",//只监听 127.0.0.1，避免除本机外的机器探测到开放了 10000 端口
      "protocol": "vmess",
      "settings": {
        "clients": [
          {
            "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
            "alterId": 64
          }
        ]
      },
      "streamSettings": {
        "network": "ws",
        "wsSettings": {
        "path": "/ray"
        }
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    }
  ]
}
```

#### Nginx 配置

配置中使用的是域名和证书使用 TLS 小节的举例，请替换成自己的。

```
server {
  listen  443 ssl;
  ssl on;
  ssl_certificate       /etc/v2ray/v2ray.crt;
  ssl_certificate_key   /etc/v2ray/v2ray.key;
  ssl_protocols         TLSv1 TLSv1.1 TLSv1.2;
  ssl_ciphers           HIGH:!aNULL:!MD5;
  server_name           mydomain.me;
        location /ray { # 与 V2Ray 配置中的 path 保持一致
        proxy_redirect off;
        proxy_pass http://127.0.0.1:10000;#假设WebSocket监听在环回地址的10000端口上
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $http_host;

        # Show realip in v2ray access.log
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }
}
```

#### Caddy 配置

因为 Caddy 会自动申请证书并自动更新，所以使用 Caddy 不用指定证书、密钥。

```
mydomain.me
{
  log ./caddy.log
  proxy /ray localhost:10000 {
    websocket
    header_upstream -Origin
  }
}
```

#### Apache 配置

同样地，配置中使用的是域名和证书使用 TLS 小节的举例，请替换成自己的。

```
<VirtualHost *:443>
  ServerName mydomain.me
  SSLCertificateFile /etc/v2ray/v2ray.crt
  SSLCertificateKeyFile /etc/v2ray/v2ray.key

  SSLProtocol -All +TLSv1 +TLSv1.1 +TLSv1.2
  SSLCipherSuite HIGH:!aNULL

  <Location "/ray/">
    ProxyPass ws://127.0.0.1:10000/ray/ upgrade=WebSocket
    ProxyAddHeaders Off
    ProxyPreserveHost On
    RequestHeader append X-Forwarded-For %{REMOTE_ADDR}s
  </Location>
</VirtualHost>
```

### 1.1.2. 客户端配置

```javascript
{
  "inbounds": [
    {
      "port": 1080,
      "listen": "127.0.0.1",
      "protocol": "socks",
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      },
      "settings": {
        "auth": "noauth",
        "udp": false
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "mydomain.me",
            "port": 443,
            "users": [
              {
                "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
                "alterId": 64
              }
            ]
          }
        ]
      },
      "streamSettings": {
        "network": "ws",
        "security": "tls",
        "wsSettings": {
          "path": "/ray"
        }
      }
    }
  ]
}
```

### 1.1.3. 注意事项

- V2Ray 暂时不支持 TLS1.3，如果开启并强制 TLS1.3 会导致 V2Ray 无法连接

- 较低版本的nginx的location需要写为 /ray/ 才能正常工作

- 如果在设置完成之后不能成功使用，可能是由于 SElinux 机制(如果你是 CentOS 7 的用户请特别留意 SElinux 这一机制)阻止了 Nginx 转发向内网的数据。如果是这样的话，在 V2Ray 的日志里不会有访问信息，在 Nginx 的日志里会出现大量的 "Permission Denied" 字段，要解决这一问题需要在终端下键入以下命令：

  ```
  setsebool -P httpd_can_network_connect 1
  ```

- 请保持服务器和客户端的 wsSettings 严格一致，对于 V2Ray，`/ray` 和 `/ray/` 是不一样的

### 1.1.4. 其他的话

1. 开启了 TLS 之后 path 参数是被加密的，GFW 看不到；
2. 主动探测一个 path 产生 Bad request 不能证明是 V2Ray；
3. 不安全的因素在于人，自己的问题就不要甩锅，哪怕我把示例中的 path 改成一个 UUID，依然有不少人原封不动地 COPY；
4. 使用 Header 分流并不比 path 安全， 不要迷信。

------

## 1.2. 更新历史

- 2017-12-05 加一些提示
- 2018-01-03 Update
- 2018-08-19 Update
- 2018-08-30 Add configuration for Apache2
- 2018-11-17 V4.0+ 配置

# 1. HTTP/2

简单地说 HTTP/2 是 HTTP/1.1 的升级版（目前大多数网页还是 HTTP/1.1），点击[这里](https://http2.akamai.com/demo)可以直观地体会到 HTTP/2 相比于 HTTP/1.1 的提升（不代表 V2Ray 中 HTTP/2 相对于 TCP 的提升就是这样的）。

由于我不清楚 V2Ray 引入 HTTP/2 的意图是什么，V2Ray 的手册也没有对此进行说明，再加上我没怎么测试过 HTTP/2 ，所以呢关于 HTTP/2 有什么高级的姿势我也不甚了解。如果有网友发现了新姿势，欢迎告知。

## 1.1. 配置

与其它的传输层协议一样在 streamSettings 中配置，不过要注意的是使用 HTTP/2 要开启 TLS。

### 1.1.1. 服务器配置

```javascript
{
  "inbounds": [
    {
      "port": 443,
      "protocol": "vmess",
      "settings": {
        "clients": [
          {
            "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
            "alterId": 64
          }
        ]
      },
      "streamSettings": {
        "network": "h2", // h2 也可写成 http，效果一样
        "httpSettings": { //此项是关于 HTTP/2 的设置
          "path": "/ray"
        },
        "security": "tls", // 配置tls
        "tlsSettings": {
          "certificates": [
            {
              "certificateFile": "/etc/v2ray/v2ray.crt", // 证书文件，详见 tls 小节
              "keyFile": "/etc/v2ray/v2ray.key" // 密钥文件
            }
          ]
        }
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    }
  ]
}
```

### 1.1.2. 客户端配置

```javascript
{
  "inbounds": [
    {
      "port": 1080,
      "listen": "127.0.0.1",
      "protocol": "socks",
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      },
      "settings": {
        "auth": "noauth",
        "udp": false
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "mydomain.me",
            "port": 443,
            "users": [
              {
                "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
                "alterId": 64
              }
            ]
          }
        ]
      },
      "streamSettings": {
        "network": "h2",
        "httpSettings": { //此项是关于 HTTP/2 的设置
          "path": "/ray"
        },
        "security": "tls"
      }
    }
  ]
}
```

## 1.2. 更新历史

- 2018-03-18 初版
- 2018-08-30 Update
- 2018-11-17 V4.0+ 配置

# 1. CDN

Cloudflare 还是太慢了，用国内的吧，绝对能体验飞一般的速度，正好 V2Ray 已经支持 HTTP/2 了，又拍云、七牛、阿里都不错，腾讯的 h2 还在内测，百度不清楚。不过说真的，CDN 的话国外的还是有些水土不服，强烈建议使用国内的，速度提升非常大，也非常稳定，高峰期毫无压力，在重点 IP 段也无所畏惧。

## 1.1. 配置

懒得写怎么配置了，会用 Cloudflare，其他的 CDN 也不会有问题。

## 1.2. 更新历史

- 2018-03-18 初版

# 1. 不推荐的配置

也许有一部分朋友发现了，高级篇的内容关于传输层的，各种配置的组合，可以搭配出非常多的配置。但是，有一些组合是我认为不值得或者是冗余的（仅代表个人意见），以下给出。

- TLS+KCP

这是相当一部分人喜欢的组合。选用KCP的原因是为了在某些恶劣的网络环境下拥有比较好的上网体验。而使用 TLS 的原因大约有两种考虑：一是认为 TLS 拥有与 HTTPS 一样的特征不容易被墙；二是觉得TLS具有更好的加密效果不容易被墙。对于第一点，尽管 HTTPS 是基于 TLS，但并不等同与 TLS，因此 TLS 与 HTTPS 的特征一样的说法是错误的；对于第二点，使用更强的加密算法而被墙的几率更小这个观点并未得到论证。然而这并不是我不推荐的理由，真正的原因的是不使用 TLS 并没什么坏处，额外使用 TLS也没有足够的好处。

- TLS+HTTP 伪装

我并没有测试过这个组合，不清楚最外层是 TLS 还是 HTTP 伪装。无论哪一种，处于内层的配置将会失去其意义。

- 单纯使用 Websocket

理论上，使用 Websocket 会比 TCP 性能差一些，单纯所以如果不是搭配 CDN、nginx 或者在 PaaS 上使用，那还是使用 TCP 吧。

# 1. 应用篇

本篇名为应用。在本篇当中不再有详尽的配置，最多只会给出配置的结构，及一些注意点。本篇的内容可能分为三种：

1. 实际验证可行
2. 理论上可行，但没在 V2Ray 上验证过
3. 纯属猜测，没有数据或者根据表明可行性

在每节当中，如果符合第 2 或第 3 点，都会特别说明。

如果本篇的内容你看不懂，那么说明：

1. 不适合你
2. 你需要学习了
3. 我的水平太差

# 1. 透明代理

透明代理是什么意思请自行 Google，在这儿指使用 V2Ray 做透明代理实现路由器翻墙。然而，我个人认为路由器翻墙的说法并不准确，应该叫网关翻墙。所以本例实际上是关于网关翻墙的内容。当然了，单纯使用路由器翻墙也是可以的，因为普通的家用路由器本就是一个网关。使用网关翻墙可以使局域网内的所有设备都具有直接翻墙的能力，并且能够全局代理，而不必每台设备都安装 V2Ray，配置更新时只需在网关修改配置，用一些网友的话说就是就感觉没有墙一样。但是，有意上透明代理的同学请评估一下透明代理是否合适自己，而不要盲目跟风。

透明代理适用于以下情况：

- 局域网设备较多，比如说办公室、实验室、大家庭等；
- 设备(的软件)无法/不方便设置代理，比如说 Chromecast、电视盒子等；
- 希望设备的所有软件都走代理。

## 1.1. 优点

其实，V2Ray 早就可以作透明代理，当时我也研究了好一段时间，最终是折腾出来了。但是由于 DNS 的问题，我用着总感觉不太舒服。虽然有 ChinaDNS 这类的解决方案，但个人主观上并不喜欢。 不过嘛，现在就不一样了。就目前来说，使用 V2Ray 透明代理：

1. 解决了墙外 DNS 污染问题；
2. 在解决了 1 的情况下国内域名的即能够解析到国内 CDN；
3. 不需要外部软件或自建 DNS 就可决绝 1 和 2 的问题，只要系统支持 V2Ray 和 iptables；
4. 能够完美利用 V2Ray 强大而灵活的路由功能，而不必额外维护一个路由表；

## 1.2. 准备

- 一个有能力根据实际情况解决遇到问题的人
- 一台已经搭建 V2Ray 并能正常使用的 VPS ，本文假设 IP 为 `110.231.43.65`；
- 一台带 iptables、有 root 权限并且系统为 Linux 的设备，假设地址为 `192.168.1.22`，已经配置好 V2Ray 作为客户端。这个设备可以是路由器、开发板、个人电脑、虚拟机和 Android 设备等，更具普适性地称之为网关。我个人不建议使用 MT7620 系路由器开透明代理，性能太差了，很多固件也没有开启 FPU 。要是真不愿意出这点钱，用电脑开个虚拟机吧(我就是这么干的)，VirtualBox、Hyper 之类的都可以，但是别忘了网络模式用网桥。

## 1.3. 设置步骤

设置步骤如下，假设使用 root。

1. 网关设备开启 IP 转发。在 /etc/sysctl.conf 文件添加一行

    

   ```
   net.ipv4.ip_forward=1
   ```

    

   ，执行下列命令生效：

   ```
   sysctl -p
   ```

2. 网关设备设置静态 IP，与路由器 LAN 口同一个网段，默认网关为路由器的IP；进入路由器的管理后台，到 DHCP 设定将默认网关地址为网关设备的 IP，本例为 192.168.1.22，或者电脑手机等设备单独设置默认网关，然后电脑/手机重新连接到路由器测试是不是可以正常上网(这时还不能翻墙)，如果不能上网先去学习一个把这个搞定，否则接下来再怎么也同样上不了网。网关设备设定静态 IP 是为了避免重启后 IP 会发生变化导致其他设备无法联网；路由器设定 DHCP 默认网关地址是为了让接入到这个路由器的设备将上网的数据包发到网关设备，然后由网关设备转发。

3. 在服务器和网关安装最新版本的 V2Ray（如果不会就参照前面的教程，由于 GFW 会恶化 GitHub Releases 的流量，网关直接运行脚本几乎无法安装，建议先下载V2Ray 的压缩包，然后用安装脚本通过 --local 参数进行安装），并配置好配置文件。一定要确定搭建的 V2Ray 能够正常使用。在网关执行 `curl -x socks5://127.0.0.1:1080 google.com` 测试配置的 V2Ray 是否可以翻墙(命令中 `socks5` 指 inbound 协议为 socks，`1080` 指该 inbound 端口是 1080)。如果出现类似下面的输出则可以翻墙，如果没有出现就说明翻不了，你得仔细检查以下哪步操作不对或漏了。

   ```
   <HTML><HEAD><meta http-equiv="content-type" content="text/html;charset=utf-8">
   <TITLE>301 Moved</TITLE></HEAD><BODY>
   <H1>301 Moved</H1>
   The document has moved
   <A HREF="http://www.google.com/">here</A>.
   </BODY></HTML>
   ```

4. 在网关的配置，添加 dokodemo door 协议的入站配置 ，并开启 sniffing；还要在所有 outbound 的 streamSettins 添加 SO_MARK。配置形如（配置中的`...`代表原来客户端的通常配置）：

   ```javascript
   {
   "routing": {...},
   "inbounds": [
    {
      ...
    },
    {
      "port": 12345, //开放的端口号
      "protocol": "dokodemo-door",
      "settings": {
        "network": "tcp,udp",
        "followRedirect": true // 这里要为 true 才能接受来自 iptables 的流量
      },
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      }
    }
   ],
   "outbounds": [
    {
      ...
      "streamSettings": {
        ...
        "sockopt": {
          "mark": 255  //这里是 SO_MARK，用于 iptables 识别，每个 outbound 都要配置；255可以改成其他数值，但要与下面的 iptables 规则对应；如果有多个 outbound，最好奖所有 outbound 的 SO_MARK 都设置成一样的数值
        }
      }
    }
    ...
   ]
   }
   ```

5. 设定 TCP 透明代理的 iptables 规则，命令如下(`#`代表注释)：

```
iptables -t nat -N V2RAY # 新建一个名为 V2RAY 的链
iptables -t nat -A V2RAY -d 192.168.0.0/16 -j RETURN # 直连 192.168.0.0/16 
iptables -t nat -A V2RAY -p tcp -j RETURN -m mark --mark 0xff # 直连 SO_MARK 为 0xff 的流量(0xff 是 16 进制数，数值上等同与上面配置的 255)，此规则目的是避免代理本机(网关)流量出现回环问题
iptables -t nat -A V2RAY -p tcp -j REDIRECT --to-ports 12345 # 其余流量转发到 12345 端口（即 V2Ray）
iptables -t nat -A PREROUTING -p tcp -j V2RAY # 对局域网其他设备进行透明代理
iptables -t nat -A OUTPUT -p tcp -j V2RAY # 对本机进行透明代理
```

然后设定 UDP 流量透明代理的 iptables 规则，命令如下

```
ip rule add fwmark 1 table 100
ip route add local 0.0.0.0/0 dev lo table 100
iptables -t mangle -N V2RAY_MASK
iptables -t mangle -A V2RAY_MASK -d 192.168.0.0/16 -j RETURN
iptables -t mangle -A V2RAY_MASK -p udp -j TPROXY --on-port 12345 --tproxy-mark 1
iptables -t mangle -A PREROUTING -p udp -j V2RAY_MASK
```

1. 使用电脑/手机尝试直接访问被墙网站，这时应该是可以访问的（如果不能，你可能得请教大神手把手指导了）。
2. 写开机自动加载上述的 iptables 的脚本，或者使用第三方软件(如 iptables-persistent)，否则网关重启后 iptables 会失效(即透明代理会失效)。

## 1.4. 注意事项

- 在上面的设置中，假设访问了国外网站，如 Google 等，网关依然会使用的系统 DNS 进行查询，只不过返回的结果是污染过的，而 V2Ray 提供的 sniffing 能够从流量中提取域名信息交由 VPS 解析。也就是说，每次打算访问被墙的网站，DNS 提供商都知道，鉴于国内企业尿性，也许 GFW 也都知道，会不会将这些数据收集喂 AI 也未可知。
- sniffing 目前只能从 TLS 和 HTTP 流量中提取域名，如果上网流量有非这两种类型的慎用 sniffing 解决 DNS 污染。
- 由于对 iptables 不熟，我总感觉上面对 UDP 流量的透明代理的设置使用上有点问题，知道为什么的朋友请反馈一下。如果你只是简单的上上网看看视频等，可以只代理 TCP 流量，不设 UDP 透明代理。
- 喜欢玩网游的朋友可能要失望了，使用 V2Ray 加速游戏效果不是很好。
- V2Ray 只能代理 TCP/UDP 的流量，ICMP 不支持，即就算透明代理成功了之后 ping Google 这类网站也是不通的。
- 按照网上其他的透明代理教程，设置 iptables 肯定要 RETURN 127.0.0.0/8 这类私有地址，但我个人观点是放到 V2Ray 的路由里好一些。

------

## 1.5. 更新历史

- 2017-12-05 初版
- 2017-12-24 修复无法访问国内网站问题
- 2017-12-27 排版
- 2017-12-29 删除不必要的 iptables 规则
- 2018-01-16 优化操作步骤
- 2018-01-21 添加 UDP
- 2018-04-05 Update
- 2018-08-30 设置步骤修正
- 2018-09-14 比较优雅地代理本机流量

# 1. 反向代理

反向代理是一个呼声比较高的功能请求，从 v2.x 版本时就有不少人询问开发者能否加入这个功能，直至 v4.0 终于推出了。反向代理的主要是用来作内网穿透，其实就是利用 VPS 访问不具有公网 IP 的内网服务器。具体的例子是，家里有一台 NAS，因为没有公网 IP，正常情况下在外面（离开了家里的网络）没法直接访问这台 NAS，但是通过反向代理就可以。如果看到这样的举例还不明白有什么用，说明你没有相关的需求，不必再折腾了。

提到反向代理，就不得不提一下如今广为推崇的 FRP，我不欲比较两者在反向代理上孰优孰劣，我只是想提一句，V2Ray 的配置相较来说会难以理解一些，希望做好准备。

## 1.1. 原理

为了易于理解，本节约定有 3 种设备，名为A, B, C。其中 A 为不具备公网 IP 的内网服务器，运行了 NAS 或个人网盘等；B 为具有公网 IP 的服务器，如平常我们购买的 VPS；C 为想要访问 NAS 或私有网盘的设备（本节假设你已经搭建好了私有网盘，监听的端口为 80）。这 3 种的每一种设备都可以是一台或多台，我们先以每种设备都是 1 台来说明。为了能够建立反向代理连接，A 和 B 都要运行 V2Ray，C 可以不运行 V2Ray 。在设置好配置文件并运行 V2Ray 之后，反向代理中连接建立的次序为：

1. A 会主动向 B 发起请求，建立起一个连接；
2. 用户在 C 上向 B 发起请求，欲访问 A 上的私有网盘；
3. B 接受 C 的请求，通过 A 向 B 建立的连接转发给 A(即 B 反向连接了 A)；

以上过程效果就相当于 C 向 A 发起请求，达到了访问 A 的私有网盘的目的。A 向 B 发起请求，A 需要一个 outbound ，B 需要一个 inbound（因为 A 的 outbound 是连接到 B 的 inbound，具备 inbound 和 outbound 的协议有 3 种：VMess, Shadowsocks 和 Socks。本节以 VMess为例）；C 向 B 发起请求，B 还需要一个 inbound，C 不运行V2（ B 的 inbound 要接受不是来自V2的流量，只能是任意门 dokodemo-door）；因为是 A 来访问最终的服务器(私有网盘)，所以 A 还需有一个 outbound，即 freedom。也就是说 A 需要两个 outbound（VMess 和 freedom），B 需要两个inbound(VMess 和 dokodemo-door)。然后为了让 A 能够主动连接 B，A 需要配置反向代理(reverse)；同样的，为了能够让 B 反向连接 A，B 也需要配置反向代理(reverse)。最后还要配置好路由。

![img](https://toutyrater.github.io/resource/images/block_of_%20reverse-doko.bmp)

## 1.2. 配置

以下给出具体配置，请结合原理部分的描述进行理解。

### 1.2.1. A 的配置

```javascript
{  
  "reverse":{ 
    // 这是 A 的反向代理设置，必须有下面的 bridges 对象
    "bridges":[  
      {  
        "tag":"bridge", // 关于 A 的反向代理标签，在路由中会用到
        "domain":"private.cloud.com" // A 和 B 反向代理通信的域名，可以自己取一个，可以不是自己购买的域名，但必须跟下面 B 中的 reverse 配置的域名一致
      }
    ]
  },
  "outbounds": [
    {  
      //A连接B的outbound  
      "tag":"tunnel", // A 连接 B 的 outbound 的标签，在路由中会用到
      "protocol":"vmess",
      "settings":{  
        "vnext":[  
          {  
            "address":"serveraddr.com", // B 地址，IP 或 实际的域名
            "port":16823,
            "users":[  
              {  
                "id":"b831381d-6324-4d53-ad4f-8cda48b30811",
                "alterId":64
              }
            ]
          }
        ]
      }
    },
    // 另一个 outbound，最终连接私有网盘    
    {  
      "protocol":"freedom",
      "settings":{  
      },
      "tag":"out"
    }    
  ],
  "routing":{   
    "rules":[  
      {  
        // 配置 A 主动连接 B 的路由规则
        "type":"field",
        "inboundTag":[  
          "bridge"
        ],
        "domain":[  
          "full:private.cloud.com"
        ],
        "outboundTag":"tunnel"
      },
      {  
        // 反向连接访问私有网盘的规则
        "type":"field",
        "inboundTag":[  
          "bridge"
        ],
        "outboundTag":"out"
      }
    ]
  }
}
```

### 1.2.2. B 的配置

```javascript
{  
  "reverse":{  //这是 B 的反向代理设置，必须有下面的 portals 对象
    "portals":[  
      {  
        "tag":"portal",
        "domain":"private.cloud.com"        // 必须和上面 A 设定的域名一样
      }
    ]
  },
  "inbounds": [
    {  
      // 接受 C 的inbound
      "tag":"external", // 标签，路由中用到
      "port":80,
      // 开放 80 端口，用于接收外部的 HTTP 访问 
      "protocol":"dokodemo-door",
        "settings":{  
          "address":"127.0.0.1",
          "port":80, //假设 NAS 监听的端口为 80
          "network":"tcp"
        }
    },
    // 另一个 inbound，接受 A 主动发起的请求  
    {  
      "tag": "tunnel",// 标签，路由中用到
      "port":16823,
      "protocol":"vmess",
      "settings":{  
        "clients":[  
          {  
            "id":"b831381d-6324-4d53-ad4f-8cda48b30811",
            "alterId":64
          }
        ]
      }
    }
  ],
  "routing":{  
    "rules":[  
      {  //路由规则，接收 C 请求后发给 A
        "type":"field",
        "inboundTag":[  
          "external"
        ],
        "outboundTag":"portal"
      },
      {  //路由规则，让 B 能够识别这是 A 主动发起的反向代理连接
        "type":"field",
        "inboundTag":[  
          "tunnel"
        ],
        "domain":[  
          "full:private.cloud.com"
        ],
        "outboundTag":"portal"
      }
    ]
  }
}
```

## 1.3. 访问

配置好 A 和 B 的 V2Ray 配置后，先后运行 A 和 B 的 V2Ray，同时搭建在 A 私有网盘也要运行。然后 C 接入跟 A 不同的网络（比如说到邻居家蹭网），用浏览器访问 B 的 IP 或域名，这时就能内网穿透访问私有网盘了。

## 1.4. 更新历史

- 2018-10-31 初版
- 2019-01-13 V4.0+ 配置格式

# 1. 反向代理 2

上一节说了反向代理，我们利用反向代理访问不具备公网 IP 的内网服务（私有网盘）。但是这种反向代理有一个局限，那就是只能分配有限的端口映射。比如说，上一节我们映射了私有网盘的 80 端口，如果我家里有好多设备，运行了很多软件（比如私有网盘、NAS、个人博客、代码仓库等），上一节说的反向代理也可以用，但是有一一分配端口映射，很不优雅，配置写起来也烦。本节介绍另一种反向代理的配置方式，解决了刚刚所举例子的问题，也具有更强的普适性，对于广大网友来说更加实用。

上面所说的可能不太好理解，我用几个实际的使用场景举例就比较容易明白了。本节所说的反向代理可以实现：

- 对于留学生等海外华人，有时候想看中文的视频或听中文音乐等，因为版权原因，没法直接上大陆的网站观看，买大陆的 VPS 又太贵。如果在大陆家里搭建一个 V2Ray，再买一个海外的 VPS，利用反向代理就可以随便看大陆可以看的视频
- 对于大学生，可以利用反向代理在校外访问校园网的资源，无限制下载论文等
- 对于程序员，可以在家里查看公司的代码仓库
- 对于普通用户，可以在外面看家里的监控

## 1.1. 原理

原理与上一节的反向代理大同小异，差别在于 B 的 dokodemo-door 改成 VMess，然后 C 需要安装 V2Ray 连接 B 的 VMess。最终的效果就是 C 通过 V2Ray 连接 B，B 反向代理给 A，就相当于 C 使用 V2Ray 通过 A 代理上网。

![img](https://toutyrater.github.io/resource/images/block_of_reverse-vmess.bmp)

（**勘误：图中 C 的 inbound 应为 Socks**）

## 1.2. 配置

以下给出具体配置，请结合原理部分的描述进行理解。

### 1.2.1. A 的配置

A 的配置与上一节无变化。

```javascript
{  
  "reverse":{ 
    // 这是 A 的反向代理设置，必须有下面的 bridges 对象
    "bridges":[  
      {  
        "tag":"bridge", // 关于 A 的反向代理标签，在路由中会用到
        "domain":"private.cloud.com" // A 和 B 反向代理通信的域名，可以自己取一个，可以不是自己购买的域名，但必须跟下面 B 中的 reverse 配置的域名一致
      }
    ]
  },
  "outbounds":[
    {  
      //A连接B的outbound  
      "tag":"tunnel", // A 连接 B的 outbound 的标签，在路由中会用到
      "protocol":"vmess",
      "settings":{  
        "vnext":[  
          {  
            "address":"serveraddr.com", // B 地址，IP 或 实际的域名
            "port":16823,
            "users":[  
              {  
                "id":"b831381d-6324-4d53-ad4f-8cda48b30811",
                "alterId":64
              }
            ]
          }
        ]
      }
    },
    // 另一个 outbound，最终连接私有网盘    
    {  
      "protocol":"freedom",
      "settings":{  
      },
      "tag":"out"
    }
  ],
  "routing":{  
    "rules":[  
      {  
      // 配置 A 主动连接 B 的路由规则
        "type":"field",
        "inboundTag":[  
          "bridge"
        ],
        "domain":[  
          "full:private.cloud.com"
        ],
        "outboundTag":"tunnel"
      },
      {  
      // 反向连接访问私有网盘的规则
        "type":"field",
        "inboundTag":[  
          "bridge"
        ],
        "outboundTag":"out"
      }
    ]    
  }
}
```

### 1.2.2. B 的配置

B 的配置只有 inbound 部分发生了变化。

```javascript
{  
  "reverse":{  //这是 B 的反向代理设置，必须有下面的 portals 对象
    "portals":[  
      {  
        "tag":"portal",
        "domain":"private.cloud.com"        // 必须和上面 A 设定的域名一样
      }
    ]
  },
  "inbounds":[
    {  
      // 接受 C 的inbound
      "tag":"tunnel", // 标签，路由中用到
      "port":11872,
      "protocol":"vmess",
      "settings":{  
        "clients":[  
          {  
            "id":"a26efdb8-ef34-4278-a4e6-2af32cc010aa",
            "alterId":64
          }
        ]
      }
    },
    // 另一个 inbound，接受 A 主动发起的请求  
    {  
      "tag": "interconn",// 标签，路由中用到
      "port":16823,
      "protocol":"vmess",
      "settings":{  
        "clients":[  
          {  
            "id":"b831381d-6324-4d53-ad4f-8cda48b30811",
            "alterId":64
          }
        ]
      }
    }
  ],
  "routing":{   
    "rules":[  
      {  //路由规则，接收 C 的请求后发给 A
        "type":"field",
        "inboundTag":[  
          "external"
        ],
        "outboundTag":"portal"
      },
      {  //路由规则，让 B 能够识别这是 A 主动发起的反向代理连接
        "type":"field",
        "inboundTag":[  
          "tunnel"
        ],
        "domain":[  
          "full:private.cloud.com"
        ],
        "outboundTag":"portal"
      }
    ]
  }
}
```

`Tips`： 在 B 的配置中，可以使用同一个 VMess inbound 来接受 A 和 C 的请求来简化配置。

### 1.2.3. C 的配置

与普通客户端配置一样，连接的服务器是B，在此忽略。

## 1.3. 访问

A、B、C 都运行 V2Ray，此时 C 访问的任何网络就相当于通过 A 访问一样(C 的路由不作特殊配置的情况下)。

## 1.4. 更新历史

- 2018-11-01 初版
- 2018-01-13 V4.0+ 配置格式

# 1. 反向代理 2

上一节说了反向代理，我们利用反向代理访问不具备公网 IP 的内网服务（私有网盘）。但是这种反向代理有一个局限，那就是只能分配有限的端口映射。比如说，上一节我们映射了私有网盘的 80 端口，如果我家里有好多设备，运行了很多软件（比如私有网盘、NAS、个人博客、代码仓库等），上一节说的反向代理也可以用，但是有一一分配端口映射，很不优雅，配置写起来也烦。本节介绍另一种反向代理的配置方式，解决了刚刚所举例子的问题，也具有更强的普适性，对于广大网友来说更加实用。

上面所说的可能不太好理解，我用几个实际的使用场景举例就比较容易明白了。本节所说的反向代理可以实现：

- 对于留学生等海外华人，有时候想看中文的视频或听中文音乐等，因为版权原因，没法直接上大陆的网站观看，买大陆的 VPS 又太贵。如果在大陆家里搭建一个 V2Ray，再买一个海外的 VPS，利用反向代理就可以随便看大陆可以看的视频
- 对于大学生，可以利用反向代理在校外访问校园网的资源，无限制下载论文等
- 对于程序员，可以在家里查看公司的代码仓库
- 对于普通用户，可以在外面看家里的监控

## 1.1. 原理

原理与上一节的反向代理大同小异，差别在于 B 的 dokodemo-door 改成 VMess，然后 C 需要安装 V2Ray 连接 B 的 VMess。最终的效果就是 C 通过 V2Ray 连接 B，B 反向代理给 A，就相当于 C 使用 V2Ray 通过 A 代理上网。

![img](https://toutyrater.github.io/resource/images/block_of_reverse-vmess.bmp)

（**勘误：图中 C 的 inbound 应为 Socks**）

## 1.2. 配置

以下给出具体配置，请结合原理部分的描述进行理解。

### 1.2.1. A 的配置

A 的配置与上一节无变化。

```javascript
{  
  "reverse":{ 
    // 这是 A 的反向代理设置，必须有下面的 bridges 对象
    "bridges":[  
      {  
        "tag":"bridge", // 关于 A 的反向代理标签，在路由中会用到
        "domain":"private.cloud.com" // A 和 B 反向代理通信的域名，可以自己取一个，可以不是自己购买的域名，但必须跟下面 B 中的 reverse 配置的域名一致
      }
    ]
  },
  "outbounds":[
    {  
      //A连接B的outbound  
      "tag":"tunnel", // A 连接 B的 outbound 的标签，在路由中会用到
      "protocol":"vmess",
      "settings":{  
        "vnext":[  
          {  
            "address":"serveraddr.com", // B 地址，IP 或 实际的域名
            "port":16823,
            "users":[  
              {  
                "id":"b831381d-6324-4d53-ad4f-8cda48b30811",
                "alterId":64
              }
            ]
          }
        ]
      }
    },
    // 另一个 outbound，最终连接私有网盘    
    {  
      "protocol":"freedom",
      "settings":{  
      },
      "tag":"out"
    }
  ],
  "routing":{  
    "rules":[  
      {  
      // 配置 A 主动连接 B 的路由规则
        "type":"field",
        "inboundTag":[  
          "bridge"
        ],
        "domain":[  
          "full:private.cloud.com"
        ],
        "outboundTag":"tunnel"
      },
      {  
      // 反向连接访问私有网盘的规则
        "type":"field",
        "inboundTag":[  
          "bridge"
        ],
        "outboundTag":"out"
      }
    ]    
  }
}
```

### 1.2.2. B 的配置

B 的配置只有 inbound 部分发生了变化。

```javascript
{  
  "reverse":{  //这是 B 的反向代理设置，必须有下面的 portals 对象
    "portals":[  
      {  
        "tag":"portal",
        "domain":"private.cloud.com"        // 必须和上面 A 设定的域名一样
      }
    ]
  },
  "inbounds":[
    {  
      // 接受 C 的inbound
      "tag":"tunnel", // 标签，路由中用到
      "port":11872,
      "protocol":"vmess",
      "settings":{  
        "clients":[  
          {  
            "id":"a26efdb8-ef34-4278-a4e6-2af32cc010aa",
            "alterId":64
          }
        ]
      }
    },
    // 另一个 inbound，接受 A 主动发起的请求  
    {  
      "tag": "interconn",// 标签，路由中用到
      "port":16823,
      "protocol":"vmess",
      "settings":{  
        "clients":[  
          {  
            "id":"b831381d-6324-4d53-ad4f-8cda48b30811",
            "alterId":64
          }
        ]
      }
    }
  ],
  "routing":{   
    "rules":[  
      {  //路由规则，接收 C 的请求后发给 A
        "type":"field",
        "inboundTag":[  
          "external"
        ],
        "outboundTag":"portal"
      },
      {  //路由规则，让 B 能够识别这是 A 主动发起的反向代理连接
        "type":"field",
        "inboundTag":[  
          "tunnel"
        ],
        "domain":[  
          "full:private.cloud.com"
        ],
        "outboundTag":"portal"
      }
    ]
  }
}
```

`Tips`： 在 B 的配置中，可以使用同一个 VMess inbound 来接受 A 和 C 的请求来简化配置。

### 1.2.3. C 的配置

与普通客户端配置一样，连接的服务器是B，在此忽略。

## 1.3. 访问

A、B、C 都运行 V2Ray，此时 C 访问的任何网络就相当于通过 A 访问一样(C 的路由不作特殊配置的情况下)。

## 1.4. 更新历史

- 2018-11-01 初版
- 2018-01-13 V4.0+ 配置格式

## 1.1. 负载均衡

相较于 Shadowsocks 等其它的代理，V2Ray 可以配置多服务器实现负载均衡。此处的负载均衡并非是自动选择一个延迟或网速最好的服务器进行连接，而是指多个服务器共同承担网络流量，从而减小单个服务器的资源占用及提高服务器的利用率。举个实际例子，早期的时候 V2Ray 优化稍差，再加上我的小鸡特别小，恰恰网络带宽非常大，所以每当使用代理全力下载大文件时 VPS 负荷很大，当时 CPU 占用率都在 80% 以上，时而超过 95%。这样的情况使得我下载东西时基本都限一下速，就怕商家停了我的机子。后来我突然想到 V2Ray 可以均衡负载，配置好双服务器均衡之后大流量下载虽然 CPU 占用率还有 50% 左右，但至少我可以毫无顾忌地大流量下载了。如今过了一年，我的小鸡全换了，V2Ray 也没当时那么吃性能了，我就再也没用过负载均衡，但是时不时有人问到，于是献出本文。

## 1.2. 配置

实现负载均衡很简单，在客户端配置同一个 outbound 的 vnext 写入各个服务器的配置即可(前提是服务器已经部署好并能正常使用)。形如：

```javascript
{
  "inbounds": [
  ...
  ],
  "outbound": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "address_of_vps1",
            "port": 8232,
            "users": [
              {
                "id": "1ce383ea-13e9-4939-9b1d-20d67135969a",
                "alterId": 64
              }
            ]
          },
          {
            "address": "address_of_vps2",
            "port": 4822,
            "users": [
              {
                "id": "bc172445-4b5e-49b2-a712-12c5295fd26b",
                "alterId": 64
              }
            ]
          }
          // 如果还有更多服务器可继续添加
        ]
      },
      "streamSettings": {
      ...
      }
    },
    ...
  ]
}
```

## 1.3. 原理

V2Ray 是以轮询的方式均衡负载，也就是说当有流量需要通过代理时，首先走第一个 vnext 配置的服务器，有第二个连接就走第二个服务器，接着第三个，以此类推。轮询完一遍又头开始轮询。这样的方式虽然简单粗暴，特别是对于拥有多个性能差的 VPS 的人来说比较有用。另外也能减小长时间大流量连接单个 IP 的特征（由于没有足够的样本，我个人对这样的条件作为代理判据持怀疑态度），给自己一个心理安慰。

## 1.4. 注意事项

如端口、id 这些在 vnext 数组内的配置项可以各不相同，但是它们的传输层配置（streamSettings）必须一致。

## 1.5. 更新历史

- 2018-01-03 初版
- 2018-04-05 Update
- 2019-01-13 v4.0+ 配置格式

# 1. Docker 部署 V2Ray

Docker 技术是一种新的虚拟化技术，和传统的虚拟化技术不同。V2Ray 同样提供 Docker 部署方式，并且通过 Docker 来部署 V2Ray 会非常轻松高效。

**Docker 只能部署在 KVM 或者 XEN 架构的 VPS中**

首先安装 Docker：

```
$ sudo apt-get install -y docker
```

安装完 Docker 后我们从 [DockerHub](https://hub.docker.com/) 通过搜索找到 V2Ray 官方提供的镜像， 链接[在此](https://hub.docker.com/r/v2ray/official/). 找到拉取镜像的的命令并复制下来，在网页右侧我们可以看到命令为 `docker pull v2ray/official` ，我们将其复制下来回到命令行中粘贴并执行：

```
$ sudo docker pull v2ray/official
```

待 V2Ray 的 Docker 镜像拉取完成后就可以进入下一个部署阶段. 在此之前，你需要在 /etc 目录下新建一个文件夹 v2ray， 并把你的配置写好后命名为 config.json 放入 v2ray 文件夹内. 待配置文件准备就绪后键入以下命令进行部署，部署前请记下配置文件中你所设置的端口号，在部署时需要将其映射到宿主机上. 否则将无法访问. 此处假设设定的端口号为8888，需要映射到宿主机的8888端口上. 则命令为：

```
$ sudo docker run -d --name v2ray -v /etc/v2ray:/etc/v2ray -p 8888:8888 v2ray/official  v2ray -config=/etc/v2ray/config.json
```

键入以上命令后，命令行会出现一串字符，代表容器部署成功，可以立即通过客户端连接并开始使用了. 如果还不放心，键入以下命令来查看容器的运行状态：

```
$ sudo docker container ls
```

如果看到输出的结果中有以下字段代表容器成功运行：

```
$ docker container ls
CONTAINER ID        IMAGE                 COMMAND                  CREATED             STATUS              PORTS                     NAMES
2a7sdo87kdf3        v2ray/official        "v2ray -config=/et..."   3 minutes ago       Up 3 minutes        0.0.0.0:8888->8888/tcp    v2ray
```

通过以下命令来启动 V2Ray：

```
$ sudo docker container start v2ray
```

停止 V2Ray：

```
$ sudo docker container stop v2ray
```

重启 V2Ray：

```
$ sudo docker container restart v2ray
```

查看日志：

```
$ sudo docker container logs v2ray
```

更新配置后，需要重新部署容器，命令如下：

```
$ sudo docker container stop v2ray
$ sudo docker container rm v2ray
$ sudo docker run -d --name v2ray -v /etc/v2ray:/etc/v2ray -p 8888:8888 v2ray/official  v2ray -config=/etc/v2ray/config.json
```

假如你的配置换了端口号，那么相应的端口映射也要更改，假如你在配置文件中把监听端口改为了9999，则'-p'参数应该这样写：

```
-p  9999:9999
```

假如你想将容器中的端口映射到本机的端口，则命令应该这样写

```
-p 127.0.0.1:端口号:端口号
```

如果 V2Ray 用的传输层协议是 mKCP，由于 mKCP 基于 UDP，那么需要指定映射的端口是 UDP：

```
-p  9999:9999/udp
```

**除非你打算使用Nginx来转发Websocket否则不需要映射到本地，直接填写端口号:端口号的形式即可**

另外，如果开启了动态端口，-p 标记可以多次使用来绑定多个端口. 具体用法是在指令中再加上多个 -p 标记即可。

更新 V2Ray 的 Docker 镜像：

```
$ docker pull v2ray/official
```

更新完之后，你需要重新部署容器，方法见上。

------

## 1.1. 更新历史

- 2018-04-05 Update
- 2018-09-06 UDP 说明

# 1. 性能测试

单位 MB/s，仅供参考。测试方法及测试工具参见[传说中的性能测试](https://steemit.com/cn/@v2ray/3cjiux) 。

## 1.1. PC 虚拟机(amd64)

### 1.1.1. VMess 性能

| -    | 直连 | freedom( V2Ray v3.10 ) | freedom( V2Ray v3.5 ) | freedom(V2Ray v2.46 ) | freedom( V2Ray v2.19 ) |
| ---- | :--: | :--------------------: | :-------------------: | :-------------------: | :--------------------: |
| 速度 | 2925 |          1137          |          249          |         1024          |          426           |

| -                 | TCP( v3.10 ) | TCP( v3.5 ) | WS( v3.5 ) | TCP( v2.46 ) | WS( v2.46 ) | TCP( v2.19 ) | WS( v2.19 ) |
| ----------------- | :----------: | :---------: | :--------: | :----------: | :---------: | :----------: | :---------: |
| AES-128-CFB       |      99      |     75      |     66     |     110      |     105     |     102      |     102     |
| AES-128-GCM       |     341      |     151     |    124     |     341      |     307     |     256      |     256     |
| CHACHA20-POLY1305 |     236      |     128     |    105     |     246      |     219     |     227      |     227     |
| NONE              |     563      |     163     |    105     |     192      |     153     |     292      |     292     |

### 1.1.2. Shadowsocks 性能

| -                 | V2Ray( v3.5 ) 内置 | ss-libev( 3.1.2 ) | ss-libev( 2.6.3 ) |
| ----------------- | :----------------: | :---------------: | :---------------: |
| AES-128-CFB       |        105         |        73         |        52         |
| AES-256-CFB       |         97         |        66         |        45         |
| AES-128-GCM       |        146         |        47         |         -         |
| AES-256-GCM       |        146         |        45         |         -         |
| CHACHA20-POLY1305 |        128         |        73         |         -         |

## 1.2. 树莓派 3b

| -    | 直连 | freedom( V2Ray v3.5 ) | freedom(V2Ray v2.46 ) |
| ---- | :--: | :-------------------: | :-------------------: |
| 速度 | 320  |          27           |          27           |

| -                 | TCP( v3.5 ) | WS( v3.5 ) | TCP( v2.46 ) |
| ----------------- | :---------: | :--------: | :----------: |
| AES-128-CFB       |      3      |     2      |      3       |
| AES-128-GCM       |     1.7     |     -      |     1.7      |
| CHACHA20-POLY1305 |      5      |     4      |      5       |
| NONE              |     21      |     12     |      22      |

# 1. 内存优化

为了更好能够提供更好的性能，V2Ray 有一个缓存机制，在上下游网络速率有差异时会缓存一部分数据。举个实际的例子，假如你在下载小姐姐，网站到你的 VPS 的速度有 500 Mbps，而 VPS 到家里宽带只有 50 Mbps，V2Ray 在 VPS 会以比较高的速率把小姐姐先下好再慢慢传到电脑里。默认情况下 V2Ray 对每个连接的缓存大小是 10 MBytes （现在默认缓存最大为 512 KBytes），也就是说如果下载小姐姐开了 32 线程，那么 V2Ray 最高会缓存 320 MBytes 的数据。这样一来那些内存只有 256 MBytes 甚至是 128 MBytes 的 VPS 压力就会比较大。所幸的是缓存的大小我们是可以修改的，减小缓存的大小可以降低对内存的占用，会对小内存机器比较友好。

## 1.1. 修改缓存

### 1.1.1. 利用环境变量修改

(**注：经过多个版本的迭代优化，V2Ray 的内存占用已经大幅度减少，默认的缓存大小最大也只有 512 KBytes，通过环境变量修改缓存参数已经不适用**)

VPS 中编辑 /etc/systemd/system/v2ray.service 文件，将 `ExecStart=/usr/bin/v2ray/v2ray -config /etc/v2ray/config.json` 修改成 `ExecStart=/usr/bin/env v2ray.ray.buffer.size=1 /usr/bin/v2ray/v2ray -config /etc/v2ray/config.json`，保存；然后执行下面的命令生效。

```
$ sudo systemctl daemon-reload && sudo systemctl restart v2ray.service
```

上面的 v2ray.ray.buffer.size 就是缓存的变量，设为 1 也没多大影响（主观感觉，没实际测试对比过），内存不太够用的朋友可以试一下。

### 1.1.2. 在配置文件中修改

在上面的通过环境变量修改缓存大小中，有一个问题是 v2ray.ray.buffer.size 的单位是 Mbytes，最小只能改成 1 Mbytes，如果改成 0 的话就意味着缓存无限制。不过在配置文件中也可以修改缓存大小，单位是 Kbytes，在配置中设成 0 的话表示禁用缓存，需要将缓存设得更小的朋友可以参考 V2Ray 官方文档的本地策略一节，配置比较简单，这里就不详述了。

## 1.2. 更新历史

- 2018-05-01 初版
- 2018-08-02 添加配置文件修改缓存
- 2018-11-11 v2ray.ray.buffer.size 废弃

# 1. 路由篇

就感觉 V2Ray 的路由功能很强大，值得我单独另起一章。本章内容没什么规划，可能会写得很零散。

# 1. 域名文件

## 1.1. 内置的域名文件

在下载 V2Ray 的时候，下载的压缩包有一个 geosite.dat。这个文件是在路由功能里用到的，文件内置了许多[常见的网站域名](https://github.com/v2ray/domain-list-community)。配置方式如下，geosite 指 geosite.dat 文件，后面的 cn 是一个标签，代表着使用 geosite.dat 文件里的 cn 规则。

```javascript
{
    "type": "field",
    "outboundTag": "direct",
    "domain": [
        "geosite:cn"
    ]
}
```

通过它可以设定这些国内域名走直连,这样就相当把规则的域名写到一个文件里，然后在配置中引用这个域名文件，其中有一个好处是配置比较简洁，看起来比较清爽。

## 1.2. 外置的域名文件

很多时候，V2Ray 内置的国内域名不能满足使用。不过 V2Ray 可以使用外部自定义的像 geosite.dat 这样的域名文件，刚好我也制作了一个，可以供大家使用。

1. 到 <https://github.com/ToutyRater/V2Ray-SiteDAT/tree/master/geofiles> 下载 h2y.dat 文件放到 V2Ray 运行文件的目录下。

2. 按需要些路由规则，格式为 "ext:h2y.dat:tag"。ext 表示使用外部文件；h2y.dat 是具体的文件名；tag 泛指标签，有哪些标签由文件提供。上个步骤下载的 h2y.dat 文件目前只有 `ad` 和 `gfw` 两个标签，ad 包含着常见的广告域名，gfw 包含着常见的被 gfw 屏蔽的域名。它们各自所包含的域名在[这里](https://github.com/ToutyRater/v2ray-SiteDAT/tree/master/h2y)可以看到。这个域名文件每星期自动更新，如果你使用了我提供的域名文件也请定期更新(打开 <https://github.com/ToutyRater/V2Ray-SiteDAT/tree/master/geofiles> 看到的都是当时的最新版本)。路由配置示例如下。

3. 运行 V2Ray。

   ```javascript
   "rules":[
    {
        "type": "field",
        "outboundTag": "block", //拦截广告相关域名
        "domain": [
            "ext:h2y.dat:ad"
        ]
    },
    {
        "type": "field",
        "outboundTag": "proxy", //被 gfw 屏蔽的域名走代理
        "domain": [
            "ext:h2y.dat:gfw"
        ]
    }
   ]
   ```

需要注意的是，目前所有第三方的 V2Ray GUI 客户端都不支持加载外置的域名文件。

## 1.3. 更新历史

- 2018-06-07 初版
- 2018-11-06 删除不必要的标签

# 1. 禁用 BT

国外版权意识比较重，如果下载盗版的影音文件很有可能会吃官司，所以大多数国外的 VPS 的使用条例都不允许下载 BT。但是一些人并不清楚这点，经常使用朋友分享给他的翻墙账号进行 BT 下载最终导致 VPS 被提供商封禁。尽管有时候说了不能使用代理下载 BT，对方也表示明白了清楚了，但总是有软件喜欢设置系统代理，也总有软件喜欢使用系统代理，好像也有不少人把路由器翻墙当成了不可或缺的，最终还是逃不了封禁的厄运。这个问题似乎从进入到 VPS 翻墙时代就困扰这大家，于是各种禁止 BT 的一键脚本也随之应运而生，也时常有人在讨论哪个脚本比较好用，其实最根本的几乎全是 IPTABLES 的字符串匹配。

在 V2Ray,修改配置文件的路由配置即可禁用 BT。不过，你要说用那些一键脚本比配置 V2Ray 更简单。嗯，你说得挺对的，很有道理。单从禁用 BT 来说的话，也许IPTABLES 的方式会好一些，也可能不是。但是别忘了，V2Ray 的路由功能可不是只能禁止连接而已，本质应该是转发。也就是说，如果你有一台无视版权的 VPS，那么大可将 BT 流量转到这台 VPS 上。

## 1.1. 服务器配置

```javascript
{
  "log": {
    "loglevel": "warning",
    "access": "/var/log/v2ray/access.log",
    "error": "/var/log/v2ray/error.log"
  },
  "inbounds": [
    {
      "sniffing": {
        "enabled": true,
        "destOverride": [
          "http",
          "tls"
        ]
      },
      "port": 16823,
      "protocol": "vmess",
      "settings": {
        "clients": [
          {
            "id": "b831381d-6324-4d53-ad4f-8cda48b30811",
            "alterId": 64
          }
        ]
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    },
    {
      "protocol": "blackhole",
      "settings": {},
      "tag": "block"
    }
  ],
  "routing": {
    "domainStrategy": "AsIs",
    "rules": [
      {
        "type": "field",
        "outboundTag": "block",
        "protocol": [
          "bittorrent"
        ]
      }
    ]
  }
}
```

`注意`: inbound 的 sniffing 必须开启。

## 1.2. 客户端配置

## 1.3. 更新历史

- 2018-08-07 初版
- 2019-01-13 v4.0+ 配置格式

# 1. 负载均衡 2

在前面的章节当中有提到过利用 V2Ray 的一个特性来实现负载均衡。但是由于这种负载均衡是投机取巧利用配置实现的，最终的效果不尽如人意，也就在特殊情况下用一用而已，也有人认为这种轮询的机制压根算不上负载均衡。不过经过漫长的等待，V2Ray 终于可均衡负载了，但是可能 V2Ray 认为时机还不成熟，官方文档上并没有负载均衡方面的描述。我研究了一番源代码，粗略测试了几分钟，V2Ray v4.3 版本可以均衡负载了，于是放出本篇教程给大伙尝尝鲜。

## 1.1. 配置

负载均衡的配置位于 routing 字段，仅需在客户端上配置即可。在 routing 当中，配置一个 balancers 数组,代表这负载均衡的规则，每一个对象包含负载均衡唯一的标签，均衡策略(目前的策略好像只有随机选择)以及可选择的出站代理。然后在路由规则中根据需要配置特定的流量进行负载均衡。在本例中，最后一个路由规则为负载均衡。根据示例可以知道目的地址是私有 IP 或中国大陆的流量直连，其余的所有流量是负载均衡 b1(即 在 jp1 和 jp2 两者之间选择)。本例中没有使用到 b2 的负载均衡。

```javascript
{

  "inbounds": [
    ...
  ],
  "outbounds": [
    {
      "tag": "us1",
      ...
    },
    {
      "tag": "jp1",
      ...
    },
    {
      "tag": "jp2",
      ...
    },
    {
      "tag": "hk1",
      ...
    },
    {
      "tag": "direct",
      ...
    }
  ],
  "routing": {
    "domainStrategy": "IPIfNonMatch",
    "balancers": [
      {
        "tag": "b1",
        "selector": [
          "jp1",
          "jp2"
        ]
      },
      {
        "tag": "b2",
        "selector": [
          "us1",
          "hk1"
        ]
      }
    ],
    "rules": [
      {
        "type": "field",
        "outboundTag": "direct",
        "ip": [
          "geoip:private",
          "geoip:cn"
        ]
      },
      {
        "type": "field",
        "outboundTag": "direct",
        "domain": [
          "geosite:cn"
        ]
      },
      {
        "type": "field",
        "network": "tcp,udp",
        "balancerTag": "b1"
      }
    ]
  }
}
```

从配置中可以看出，V2Ray 的负载均衡同样有着高度灵活的优点，可以针对指定的流量进行负载均衡，也可以按需配置多个负载均衡，不同底层传输配置的出站协议也可以负载均衡，可以说 V2Ray 的路由有多灵活那么它的负载均衡就有多灵活。

可能是刚刚推出的原因，现在的均衡策略只有随机选择，随着时间的推进应该会陆续有其他的策略。

以上配置是我根据 V2Ray v4.3 的源代码写的，在正式的文档出来之前只适合尝鲜使用。

## 1.2. 更新历史

- 2018-11-09 初版